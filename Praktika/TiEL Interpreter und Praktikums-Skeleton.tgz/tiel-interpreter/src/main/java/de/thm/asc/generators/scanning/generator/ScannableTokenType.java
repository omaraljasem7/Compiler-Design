package de.thm.asc.generators.scanning.generator;

public interface ScannableTokenType {
}
