package de.thm.asc.tiel.interpreter.util;

import java.util.Optional;
import java.util.function.Supplier;

public class LazyValue<T> {
    private Supplier<T> computation;
    private Optional<T> value = Optional.empty();

    public LazyValue(Supplier<T> computation) {
        this.computation = computation;
    }

    public T get() {
        if (value.isEmpty()) {
            value = Optional.of(this.computation.get());
        }
        return value.get();
    }
}
