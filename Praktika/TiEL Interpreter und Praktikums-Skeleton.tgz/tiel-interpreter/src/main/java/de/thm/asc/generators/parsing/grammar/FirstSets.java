package de.thm.asc.generators.parsing.grammar;

import de.thm.asc.tiel.interpreter.util.MarkdownTable;

import java.util.*;
import java.util.stream.Collectors;

public class FirstSets {

    private final Grammar grammar;
    private final Map<Symbol.NonTerminal, Set<FirstElement>> firstSets = new HashMap<>();

    public FirstSets(Grammar grammar) {
        this.grammar = grammar;

        if (!this.grammar.type.get().isSubSetOf(GrammarType.TYPE2_CONTEXTFREE))
            throw new UnsupportedOperationException("Cannot calculate first sets for non context-free grammar.");

        this.calculate();
    }

    /**
     * Populates the internal cache {@link FirstSets#firstSets} of first sets for the entire grammar.
     */
    private void calculate() {
        // TODO (Aufgabe 2): Implement the calculation of the first sets by populating the firstSets map in this class.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /**
     * Calculates the first set of a given list of symbols in regard to the provided grammar.
     *
     * @param symbols The symbols to calculate the first set of.
     * @return The first set.
     */
    public Set<FirstElement> getForSymbolString(List<Symbol> symbols) {
        var firstSet = new HashSet<FirstElement>();
        var canBeEpsilon = true;

        for (var i = 0; i < symbols.size() && canBeEpsilon; i++) {
            var s = symbols.get(i);

            if (s instanceof Symbol.Terminal t) {
                canBeEpsilon = false;
                firstSet.add(FirstElement.of(t, t.getRepresentation()));
            } else if (s instanceof Symbol.NonTerminal n) {
                var set = this.firstSets.get(n);

                firstSet.addAll(set.stream().filter(e -> !e.isEpsilon()).toList());

                if (set.stream().noneMatch(FirstElement::isEpsilon)) {
                    canBeEpsilon = false;
                }
            }
        }

        if (canBeEpsilon) {
            firstSet.add(FirstElement.EPSILON);
        }

        return firstSet;
    }

    /**
     * Generates a Markdown table from this instance.
     *
     * @return The Markdown table.
     */
    public MarkdownTable toMarkdownTable() {
        var table = new MarkdownTable()
                .setHeader(new MarkdownTable.Row()
                        .addCell("Non-Terminal").addCell("First Set"));

        for (var e : firstSets.entrySet()) {
            table.addRow(new MarkdownTable.Row()
                    .addCell(String.valueOf(e.getKey().value()))
                    .addCell(e.getValue().stream()
                            .map(s -> String.valueOf(s.isEpsilon() ? "ε" : s.symbol().value()))
                            .collect(Collectors.joining(", "))));
        }

        return table;
    }

    /**
     * Get the first set for a given nonterminal
     *
     * @param symbol The nonterminal.
     * @return The first set of that nonterminal.
     */
    public Set<FirstElement> get(Symbol.NonTerminal symbol) {
        return this.firstSets.get(symbol);
    }

    public record FirstElement(Optional<Symbol.Terminal> _symbol, String literal) {
        public Symbol.Terminal symbol() {
            if (this._symbol.isEmpty()) {
                throw new RuntimeException("symbol() called on an epsilon first set element.");
            }

            return this._symbol.get();
        }

        public boolean isEpsilon() {
            return this._symbol.isEmpty();
        }

        public static final FirstElement EPSILON = new FirstElement(Optional.empty(), "");

        public static FirstElement of(Symbol.Terminal symbol, String literal) {
            return new FirstElement(Optional.of(symbol), literal);
        }
    }
}


