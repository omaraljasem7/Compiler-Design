package de.thm.asc.tiel.interpreter.backend.codegeneration;

import de.thm.asc.teir.StackInstruction;
import de.thm.asc.tiel.interpreter.ast.expr.*;
import de.thm.asc.tiel.interpreter.ast.stmt.*;
import de.thm.asc.tiel.interpreter.backend.common.TiELValue;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class CodeGenerator {

    static class StatefulGenerator {

        private final List<StackInstruction> buffer = new ArrayList<>();

        void append(StackInstruction... instructions) {
            this.buffer.addAll(List.of(instructions));
        }
    }

    static void generate(Expr expr, StatefulGenerator state) {
        switch (expr) {
            /* TODO (Aufgabe 3): Implement code generation for all expression types */
            default -> state.append(new StackInstruction.TiELInterpretedExpressionFallback(expr));
        }
    }

    static void generate(Stmt stmt, StatefulGenerator state) {
        /* TODO (Bonusaufgabe): Implement code generation for all statement types */

        switch (stmt) {
            case ExpressionStmt expressionStmt -> {
                generate(expressionStmt.expression, state);
                state.append(new StackInstruction.Pop());
            }
            default -> state.append(new StackInstruction.TiELInterpretedStatementFallback(stmt));
        }
    }

    public static List<StackInstruction> generate(List<Stmt> program) {
        var state = new StatefulGenerator();

        for (var s : program) {
            generate(s, state);
        }

        return state.buffer;
    }
}
