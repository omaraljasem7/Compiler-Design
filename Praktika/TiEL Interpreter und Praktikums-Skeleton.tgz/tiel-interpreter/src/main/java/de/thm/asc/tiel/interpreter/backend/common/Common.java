package de.thm.asc.tiel.interpreter.backend.common;

public class Common {

    /**
     * Checks if an value is truthy according to TiEL's rules.
     *
     * @param value The value to check.
     * @return True if the object is truthy, false otherwise.
     */
    public static boolean isTruthy(TiELValue value) {
        if (value instanceof TiELValue.TNil) return false;
        if (value instanceof TiELValue.TBoolean(boolean v)) return v;
        return true;
    }

    public static TiELValue wrap(double number) {
        return new TiELValue.TNumber(number);
    }

    public static TiELValue wrap(boolean number) {
        return new TiELValue.TBoolean(number);
    }
}
