package de.thm.asc.tiel.interpreter.parsing;

import de.thm.asc.generators.parsing.generator.ParserSpecification;
import de.thm.asc.tiel.interpreter.ast.AstPrinter;
import de.thm.asc.tiel.interpreter.ast.expr.AssignExpr;
import de.thm.asc.tiel.interpreter.ast.expr.BinaryExpr;
import de.thm.asc.tiel.interpreter.ast.expr.LiteralExpr;
import de.thm.asc.tiel.interpreter.ast.expr.VariableExpr;
import de.thm.asc.tiel.interpreter.ast.stmt.ExpressionStmt;
import de.thm.asc.tiel.interpreter.ast.stmt.Stmt;
import de.thm.asc.tiel.interpreter.backend.common.TiELValue;
import de.thm.asc.tiel.interpreter.scanning.TiELScannerHandwritten;
import de.thm.asc.tiel.interpreter.scanning.TokenType;

import java.util.ArrayList;
import java.util.List;

import static de.thm.asc.tiel.interpreter.scanning.TokenType.*;

public class ParserExample {

    private static <T> List<T> cons(T head, List<T> tail) {
        var list = new ArrayList<T>();
        list.add(head);
        list.addAll(tail);
        return list;
    }

    private static ParserSpecification specification() {
        var parser = new ParserSpecification.Builder(TokenType.class);

        var start = parser.nonTerminal("start");

        var statements = parser.nonTerminal("statements");
        var statement = parser.nonTerminal("statement");
        var assignment = parser.nonTerminal("assignment");
        var expression = parser.nonTerminal("expression");
        var literal = parser.nonTerminal("literal");
        var operator = parser.nonTerminal("operator");

        parser.startSymbol(start);

        start.produces(statements, EOF).withSemantic($ -> $.get(0));

        statements.produces(statement, statements).withSemantic($ -> cons($.get(0), $.get(1)));
        statements.produces().withSemantic($ -> new ArrayList<Stmt>()); // epsilon

        statement.produces(assignment).withSemantic(ExpressionStmt.class);

        assignment.produces(IDENTIFIER, EQUAL, expression, SEMICOLON).withSemantic(AssignExpr.class);

        expression.produces(literal, operator, literal).withSemantic(BinaryExpr.class);

        operator.produces(PLUS).withSemantic($ -> BinaryExpr.Operator.ADD);
        operator.produces(MINUS).withSemantic($ -> BinaryExpr.Operator.SUB);

        literal.produces(NUMBER).withSemantic($ -> new LiteralExpr(new TiELValue.TNumber($.get(0))));
        literal.produces(IDENTIFIER).withSemantic($ -> new VariableExpr($.get(0)));

        return parser.getSpecification();
    }

    public static TiELParser getParser() {
        return new TiELParserGenerated.LL1TiELParser(specification());
    }

    public static void main(String[] args) {
        var code = "test = 2 + 3; axolotl = test - 2;";

        var tokens = TiELScannerHandwritten.getScanner().scan(code);
        var ast = getParser().parse(tokens);

        System.out.println(new AstPrinter().print(ast));
    }
}
