package de.thm.asc.generators.scanning.automata;

import java.util.*;
import java.util.stream.Collectors;

/**
 * The Rabin-Scott powerset construction algorithm can be used to convert any nondeterministic finite automaton into a deterministic finite automaton.
 * The intuition behind that possibility is that when simulating a nfa on an input at any point you are in a superposition of any subset of states in the nfa.
 * <p>
 * The number of subsets, while exponentially larger, is still finite. So by enumerating and creating a new state in a new automaton for all relevant subsets,
 * and then creating transitions for every transition for any of the original states in a set to all other relevant subset-states, we can achieve a DFA.
 */
public class PowersetConstruction {

    public static FiniteAutomaton apply(FiniteAutomaton nfa) {
        return new PowersetConstruction(nfa).construct();
    }

    private final FiniteAutomaton nfa;
    private final FastTransitionTable fastLookup;

    protected PowersetConstruction(FiniteAutomaton nfa) {
        this.nfa = nfa;
        this.fastLookup = FastTransitionTable.construct(nfa);
    }

    private Set<State> epsilonClosure(State s) {
        return epsilonClosure(Set.of(s));
    }

    private Set<State> epsilonClosure(Set<State> s) {
        /* TODO (Aufgabe 1): Implement the calculation of the epsilon closure.*/

        throw new RuntimeException("Not yet implemented");
    }

    public record ResultWithStateMap(
            FiniteAutomaton resultAutomaton,
            Map<State, Set<State>> originalStateMap
    ) {}

    protected ResultWithStateMap constructWithStateMap() {
        var builder = new FiniteAutomatonBuilder();
        var convertedStates = new HashMap<Set<State>, State>();

        /* TODO (Aufgabe 1): Implement the powerset construction algorithm. Make sure to track the mapping from original state sets to the new states in the map above. */

        return new ResultWithStateMap(
                builder.result(),
                convertedStates.entrySet().stream().collect(Collectors.toMap(Map.Entry::getValue, Map.Entry::getKey))
        );
    }

    private FiniteAutomaton construct() {
        return constructWithStateMap().resultAutomaton;
    }
}
