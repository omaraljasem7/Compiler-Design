package de.thm.asc.tiel.interpreter.backend.common;

import de.thm.asc.tiel.interpreter.error.RuntimeError;
import de.thm.asc.tiel.interpreter.scanning.Token;

import java.io.PrintStream;
import java.util.List;

public class Globals {

    public static Environment initGlobalEnvironment(PrintStream out) {
        var globals = new Environment();

        globals.define("print", new TiELCallable() {
            @Override
            public int arity() {
                return 1;
            }

            @Override
            public TiELValue call(List<TiELValue> arguments, Token.Position errorPosition) {
                out.println(arguments.getFirst().toString());
                return TiELValue.NIL;
            }

            @Override
            public String toString() {
                return "<native fn>";
            }
        }, Token.Position.ZERO);

        globals.define("floor", new TiELCallable() {
            @Override
            public int arity() {
                return 1;
            }

            @Override
            public TiELValue call(List<TiELValue> arguments, Token.Position errorPosition) {
                if (arguments.getFirst() instanceof TNumber(double value)) {
                    return new TNumber(Math.floor(value));
                }

                throw new RuntimeError("Expected argument to floor to be a number", errorPosition);
            }

            @Override
            public String toString() {
                return "<native fn>";
            }
        }, Token.Position.ZERO);

        return globals;
    }
}
