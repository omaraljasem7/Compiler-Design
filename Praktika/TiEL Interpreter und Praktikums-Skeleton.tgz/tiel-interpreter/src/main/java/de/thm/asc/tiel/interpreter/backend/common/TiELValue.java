package de.thm.asc.tiel.interpreter.backend.common;

public sealed interface TiELValue permits TiELCallable, TiELValue.TBoolean, TiELValue.TNil, TiELValue.TNumber,
        TiELValue.TString, TiELValue.TeIRClosure {

    record TNumber(double value) implements TiELValue {

        @Override
        public String toString() {
            var text = String.valueOf(value);
            if (text.endsWith(".0")) {
                text = text.substring(0, text.length() - 2);
            }
            return text;
        }
    }

    record TString(String value) implements TiELValue {

        @Override
        public String toString() {
            return value;
        }
    }

    record TBoolean(boolean value) implements TiELValue {

        @Override
        public String toString() {
            return String.valueOf(value);
        }
    }

    record TNil() implements TiELValue {

        @Override
        public String toString() {
            return "nil";
        }
    }

    record TeIRClosure(java.lang.String label, Environment environment) implements TiELValue {

    }

    TiELValue TRUE = new TBoolean(true);
    TiELValue FALSE = new TBoolean(false);
    TiELValue NIL = new TNil();
}
