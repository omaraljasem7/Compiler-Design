package de.thm.asc.tiel.interpreter.scanning;

import java.util.List;

public interface TiELScanner {
    List<Token> scan(String input);
}
