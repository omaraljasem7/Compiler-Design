package de.thm.asc.generators.scanning.regex.ast;

/**
 * Alternation nodes describe alternatives in Regex such as `a|b`.
 */
public final class AlternationNode extends RegularExpression {

    public final RegularExpression left;
    public final RegularExpression right;

    public AlternationNode(final RegularExpression left, final RegularExpression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    protected int getPrecedence() {
        return 1;
    }

    @Override
    public String toString() {
        // Precedence handling not necessary because alternation binds the weakest anyway.
        return String.format("%s|%s", left, right);
    }
}
