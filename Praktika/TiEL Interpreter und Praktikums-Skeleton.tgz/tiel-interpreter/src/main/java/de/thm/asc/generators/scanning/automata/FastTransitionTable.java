package de.thm.asc.generators.scanning.automata;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * This utility class provides faster lookup for common transition queries in a finite automaton compared to searching and filtering the whole transition set.
 * Construct via the static constructor function.
 *
 * @param automaton          The underlying automaton
 * @param epsilonTransitions A map containing all epsilon transitions of the automaton mapped to the set of states they lead to.
 * @param symbolTransitions  A map containing all symbol transitions of the automaton mapped to a map containing all transitions mapped to the set of states they lead to.
 */
public record FastTransitionTable(FiniteAutomaton automaton,
                                  Map<State, Set<State>> epsilonTransitions,
                                  Map<State, Map<Symbol, Set<State>>> symbolTransitions
) {

    public static FastTransitionTable construct(FiniteAutomaton nfa) {
        var epsilonTransitions = new HashMap<State, Set<State>>();
        var symbolTransitions = new HashMap<State, Map<Symbol, Set<State>>>();

        for (var t : nfa.transitions()) {
            if (t.isEpsilonTransition()) {
                epsilonTransitions.computeIfAbsent(t.left, k -> new HashSet<>()).add(t.right);
            } else {
                symbolTransitions.computeIfAbsent(t.left, k -> new HashMap<>())
                        .computeIfAbsent(t.symbol(), k -> new HashSet<>()).add(t.right);
            }
        }

        return new FastTransitionTable(nfa, epsilonTransitions, symbolTransitions);
    }

    /**
     * Get all epsilon transitions for a state.
     *
     * @param state A state.
     * @return All states reachable by a single epsilon transitions from the given state. Does NOT compute the epsilon closure.
     */
    public Set<State> epsilonTransitions(State state) {
        return epsilonTransitions.computeIfAbsent(state, k -> new HashSet<>());
    }

    /**
     * Get all symbol transitions for a state grouped by the respective symbol.
     *
     * @param state A state.
     * @return A map mapping symbols to the set of states that can be reached with that symbol from the given state.
     */
    public Map<Symbol, Set<State>> symbolTransitions(State state) {
        return symbolTransitions.computeIfAbsent(state, k -> new HashMap<>());
    }

    /**
     * Get a map of all transitions for a given set of states.
     *
     * @param states The state set to consider.
     * @return A map mapping symbols to the set of states that can be reached with that symbol from any of the given input states.
     */
    public Map<Symbol, Set<State>> symbolTransitions(Set<State> states) {
        var result = new HashMap<Symbol, Set<State>>();

        for (var state : states) {
            for (var transition : symbolTransitions(state).entrySet()) {
                var key = transition.getKey();
                var value = transition.getValue();

                result.merge(key, value, (a, b) ->
                        Stream.concat(a.stream(), b.stream()).collect(Collectors.toSet()));
            }
        }

        return result;
    }

    /**
     * Get the next state for a state and an input symbol.
     *
     * @param state  A state.
     * @param symbol The next input symbol.
     * @return The next state for the given input symbol in the given state. None if there is no transition for the given symbol.
     */
    public Optional<State> next(State state, Symbol symbol) {
        var set = symbolTransitions(state).get(symbol);

        if (set == null) return Optional.empty();

        return set.stream().findAny();
    }
}