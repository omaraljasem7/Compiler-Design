package de.thm.asc.generators.parsing.parser.ll1;

import de.thm.asc.generators.parsing.generator.ParseableSymbol;
import de.thm.asc.generators.parsing.grammar.FollowSets;
import de.thm.asc.generators.parsing.grammar.Production;
import de.thm.asc.generators.parsing.parser.DerivationTree;
import de.thm.asc.generators.parsing.grammar.Symbol;
import de.thm.asc.generators.scanning.generator.ScannableTokenType;
import de.thm.asc.tiel.interpreter.error.ParsingError;
import de.thm.asc.tiel.interpreter.scanning.Token;
import de.thm.asc.tiel.interpreter.util.MarkdownTable;

import java.util.*;
import java.util.stream.Collectors;

public class LL1Automaton {

    public final LL1Table table;

    public LL1Automaton(LL1Table table) {
        this.table = table;
    }

    public LL1ParseResult parse(List<Token> tokens) {
        var recording = new StateRecording();

        // Add the input in a queue.
        var inputQueue = new LinkedList<>(tokens.stream()
                .map(c -> {
                    var followElement = FollowSets.FollowElement.of((Symbol.Terminal) ((ParseableSymbol) c.type()).getUnderlyingSymbol());

                    return new FollowElementWithLexeme(followElement, c);
                })
                .toList());

        // Initialize the derivation tree with the start symbol as the underived root node .
        var tree = new DerivationTree(table.grammar);

        // Initialize the stack with just the root of the derivation tree
        var stack = new ArrayDeque<>(List.of(tree.getRoot()));

        // Add the end of input marker to the input queue.
        inputQueue.offer(new FollowElementWithLexeme(FollowSets.FollowElement.DOLLAR, null));

        while (!stack.isEmpty()) {
            recording.recordState(stack, inputQueue);

            // The top element of the stack is always consumed.
            var top = stack.pop();

            var next = inputQueue.peek();

            // We always stop when we find the end of input marker, so we know that next is never null. But java doesn't know that.
            assert (next != null);

            switch (top.symbol) {
                case Symbol.NonTerminal topNonterminal -> {
                    var production = table.get(topNonterminal, next.followElement);

                    if (production == null) {
                        var expected = table.getExpectedForNonterminal(topNonterminal);
                        var expectedString = expected.size() == 1
                                ? ""
                                : "one of [" + expected.stream().map(FollowSets.FollowElement::toString).collect(Collectors.joining(", ")) + "]";

                        // Cell in table is empty, error.
                        recording.recordError(
                                new ParsingError("Unexpected token '%s', expected %s".formatted(next.token.lexeme(),
                                        expectedString),
                                        next.token.position()));
                        return new LL1ParseResult(Optional.empty(), recording);
                    } else {
                        // Cell is not empty, create children nodes for all symbols on the right hand side.
                        var children = production.right().stream().map(tree::createNode).toList();

                        // Set the children for the nonterminal node in the tree.
                        top.setDerivation(children);
                        top.setProduction(production);

                        // Add children to the stack in reverse order so that the leftmost element is on top.
                        children.reversed().forEach(stack::push);
                        recording.recordPush(production);
                    }
                }
                case Symbol.Terminal(ScannableTokenType topValue) -> {
                    if (next.followElement.isDollar()) {
                        // Stack is not empty, but input it: Error
                        recording.recordError(new ParsingError("Unexpected end of input.",
                                next.token.position()));
                        return new LL1ParseResult(Optional.empty(), recording);
                    } else if (next.followElement.symbol().value() == topValue) {
                        // Top of stack matches next input element: Pop both
                        inputQueue.remove();
                        recording.recordPop((Symbol.Terminal) top.symbol);

                        top.setToken(next.token);
                    } else {
                        // Top of stack does not match next input element: Error
                        recording.recordError(
                                new ParsingError("Unexpected token '%s', expected %s.".formatted(next.token.lexeme(),
                                        topValue.toString()),
                                        next.token.position()));
                        return new LL1ParseResult(Optional.empty(), recording);
                    }
                }
            }
        }

        recording.recordState(stack, inputQueue);

        // If the stack and the remaining input are empty: Accept the word, else error
        if (inputQueue.size() == 1 && inputQueue.poll().followElement.isDollar()) {
            recording.recordAccept();
        } else {
            recording.recordError(new ParsingError("Syntax error: unconsumed input remaining",
                    Token.Position.ZERO));
        }

        return new LL1ParseResult(Optional.of(tree), recording);
    }

    public record LL1ParseResult(
            Optional<DerivationTree> derivationTree,
            StateRecording recording
    ) {
    }

    /**
     * This class can be used to record the individual steps of an LL1 parser.
     * It is just a dumb table for debugging and visualization purposes, and does not perform any of the actual parsing logic.
     */
    public static class StateRecording {

        private final List<State> states = new ArrayList<>();

        public List<State> getStates() {
            return states;
        }

        void recordState(Deque<DerivationTree.Node> stack, Queue<FollowElementWithLexeme> input) {
            var mappedStack = stack.stream().map(n -> n.symbol).toList();
            var remainingInput = input.stream().map(e -> e.followElement).toList();

            states.add(new State(mappedStack, remainingInput, null));
        }

        private void recordAction(Action action) {
            states.set(states.size() - 1, states.getLast().withAction(action));
        }

        void recordPop(Symbol.Terminal terminal) {
            recordAction(new PopAction(terminal));
        }

        void recordPush(Production production) {
            recordAction(new PushAction(production));
        }

        void recordAccept() {
            recordAction(new AcceptAction());
        }

        void recordError(ParsingError error) {
            recordAction(new ErrorAction(error));
        }

        public MarkdownTable toMarkdownTable() {
            var table = new MarkdownTable()
                    .setHeader(new MarkdownTable.Row()
                            .addCell("Content of Stack")
                            .addCell("Remaining Input")
                            .addCell("Action"));

            for (var s : states) {
                table.addRow(new MarkdownTable.Row()
                        .addCell(s.stack().stream().map(Symbol::getRepresentation).collect(Collectors.joining(" ")))
                        .addCell(s.remainingInput.stream().map(i -> i.isDollar() ? "$" : i.symbol().getRepresentation()).collect(Collectors.joining(" ")))
                        .addCell(s.action.toString()));
            }

            return table;
        }

        sealed interface Action {
        }

        record PopAction(Symbol.Terminal terminal) implements Action {
            @Override
            public String toString() {
                return String.format("pop %s", terminal.getRepresentation());
            }
        }

        record PushAction(Production production) implements Action {
            @Override
            public String toString() {
                return String.format("%s -> %s",
                        production.left().stream().map(Symbol::getRepresentation).collect(Collectors.joining()),
                        production.right().stream().map(Symbol::getRepresentation).collect(Collectors.joining()));
            }
        }

        public record ErrorAction(ParsingError error) implements Action {
            @Override
            public String toString() {
                return "error";
            }
        }

        record AcceptAction() implements Action {
            @Override
            public String toString() {
                return "accept";
            }
        }

        public record State(List<Symbol> stack, List<FollowSets.FollowElement> remainingInput, Action action) {
            State withAction(Action action) {
                return new State(stack, remainingInput, action);
            }
        }
    }

    public record FollowElementWithLexeme(FollowSets.FollowElement followElement, Token token) {
    }
}


