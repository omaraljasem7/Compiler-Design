package de.thm.asc.tiel.interpreter;

import de.thm.asc.generators.scanning.generator.PowersetConstructionWithSemanticActions;
import de.thm.asc.generators.scanning.generator.ScannerThompsonsConstruction;
import de.thm.asc.teir.StackInstruction;
import de.thm.asc.tiel.interpreter.ast.AstPrinter;
import de.thm.asc.tiel.interpreter.ast.stmt.Stmt;
import de.thm.asc.tiel.interpreter.backend.TiELBackend;
import de.thm.asc.tiel.interpreter.backend.codegeneration.CodeGenerator;
import de.thm.asc.tiel.interpreter.backend.common.Globals;
import de.thm.asc.tiel.interpreter.error.ParsingError;
import de.thm.asc.tiel.interpreter.error.RuntimeError;
import de.thm.asc.tiel.interpreter.error.Error;
import de.thm.asc.tiel.interpreter.parsing.TiELParser;
import de.thm.asc.tiel.interpreter.parsing.TiELParserHandwritten;
import de.thm.asc.tiel.interpreter.parsing.TiELParserGenerated;
import de.thm.asc.tiel.interpreter.scanning.TiELScanner;
import de.thm.asc.tiel.interpreter.scanning.TiELScannerGenerated;
import de.thm.asc.tiel.interpreter.scanning.TiELScannerHandwritten;
import de.thm.asc.tiel.interpreter.util.LazyValue;
import picocli.CommandLine;

import static picocli.CommandLine.*;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.util.List;
import java.util.concurrent.Callable;

@Command(name = "tiel", mixinStandardHelpOptions = true, version = "tiel 1.0")
public class Main implements Callable<Integer> {

    private enum ParameterScanner {
        HANDWRITTEN, GENERATED;

        public final LazyValue<TiELScanner> implementation = new LazyValue<>(() -> switch (this) {
            case HANDWRITTEN -> TiELScannerHandwritten.getScanner();
            case GENERATED -> TiELScannerGenerated.SCANNER.get();
        });
    }

    private enum ParameterParser {
        HANDWRITTEN, GENERATED;

        public final LazyValue<TiELParser> implementation = new LazyValue<>(() -> switch (this) {
            case HANDWRITTEN -> TiELParserHandwritten.getParser();
            case GENERATED -> TiELParserGenerated.PARSER.get();
        });

    }

    private enum ParameterBackend {
        INTERPRETER, TEIR_VM;

        public final LazyValue<TiELBackend> implementation = new LazyValue<>(() -> switch (this) {
            case INTERPRETER -> TiELBackend.interpreterBackend();
            case TEIR_VM -> TiELBackend.teirVMBackend();
        });
    }

    @Parameters(index = "0", description = "Source code file to execute.", arity = "1")
    private File input;

    @Option(names = {"-s", "--scanner"}, description = "The scanner to use for lexical analysis (${COMPLETION-CANDIDATES}).", defaultValue = "HANDWRITTEN")
    private ParameterScanner scanner;

    @Option(names = {"-p", "--parser"}, description = "The parser to use for syntactical analysis (${COMPLETION-CANDIDATES}).", defaultValue = "HANDWRITTEN")
    private ParameterParser parser;

    @Option(names = {"-b", "--backend"}, description = "The backend to use to execute the provided program (${COMPLETION-CANDIDATES}).", defaultValue = "INTERPRETER")
    private ParameterBackend backend;

    @Option(names = {"--tokens"}, description = "Print scanned tokens.", arity = "0")
    private boolean printTokens;

    @Option(names = {"--ast"}, description = "Print generated AST.", arity = "0")
    private boolean printAst;

    @Option(names = "--scannernfa", description = "Print the nondeterministic automaton for the generated scanner after thompson construction as dot code for graphviz.", arity = "0")
    private boolean printNFA;

    @Option(names = "--scannerdfa", description = "Print the deterministic automaton for the generated scanner after powerset construction as dot code for graphviz.", arity = "0")
    private boolean printDFA;

    @Option(names = "--grammar", description = "Print the grammar for the generated parser..", arity = "0")
    private boolean printGrammar;

    @Option(names = "--ll1table", description = "Print the generated LL1 table, as well as the first- and follow-sets of the underlying grammar.", arity = "0")
    private boolean printLL1Table;

    @Option(names = "--ll1trace", description = "Print a trace of the LL1 automaton. Requires parser=GENERATED.", arity = "0")
    private boolean printLL1Trace;

    @Option(names = "--vmcode", description = "Print generated TeIR VM code.", arity = "0")
    private boolean printVmCode;

    @Override
    public Integer call() throws Exception {
        try {
            if (printNFA || printDFA) {
                var nfa = ScannerThompsonsConstruction.construct(TiELScannerGenerated.specification());

                if (printNFA) {
                    System.out.println("Scanner NFA before powerset construction:");
                    System.out.println(nfa.automaton().toDotCode());
                    System.out.println();
                }

                if (printDFA) {
                    var dfa = PowersetConstructionWithSemanticActions.generate(nfa);

                    System.out.println("Scanner DFA after powerset construction:");
                    System.out.println(dfa.automaton().toDotCode());
                    System.out.println();
                }
            }

            if (printGrammar) {
                System.out.println("Grammar for generated parser:");
                System.out.println(TiELParserGenerated.PARSER.get().specification.grammar().toString());
                System.out.println();
            }

            if (printLL1Table) {
                var ll1parser = TiELParserGenerated.PARSER.get();

                System.out.println("First Sets:");
                ll1parser.specification.grammar().firstSets.get().toMarkdownTable();
                System.out.println();

                System.out.println("Follow Sets:");
                ll1parser.specification.grammar().followSets.get().toMarkdownTable();
                System.out.println();

                System.out.println("LL1Table:");
                System.out.println(ll1parser.automaton.table.toMarkdownTable().toString());
                System.out.println();
            }

            String source;
            try {
                source = new String(Files.readAllBytes(input.toPath()));
            } catch (NoSuchFileException e) {
                System.out.printf("File %s could not be read%n", input.getPath());
                return 1;
            }

            var tokens = scanner.implementation.get().scan(source);

            if (printTokens) {
                System.out.println("Scanned tokens:");
                for (var t : tokens) {
                    System.out.println(t);
                }
                System.out.println();
            }

            if (printLL1Trace) {
                if (!(parser.implementation.get() instanceof TiELParserGenerated.LL1TiELParser ll1parser)) {
                    System.out.println("Ignoring --ll1trace: Parser is not set to GENERATED.");
                } else {
                    var result = ll1parser.automaton.parse(tokens);

                    System.out.println("LL1Trace:");
                    System.out.println(result.recording().toMarkdownTable().toString());
                    System.out.println();
                }
            }

            List<Stmt> ast = parser.implementation.get().parse(tokens);

            if (printAst) {
                System.out.println("Generated AST:");
                System.out.println(new AstPrinter().print(ast));
                System.out.println();
            }

            if (printVmCode) {
                var vmCode = CodeGenerator.generate(ast);
                System.out.println("Generated VM code:");
                for (var i : vmCode) {
                    System.out.println(StackInstruction.prettyPrint(i));
                }
            }

            backend.implementation.get().build(ast).executeIn(Globals.initGlobalEnvironment(System.out));
        } catch (Error e) {
            System.err.printf("An error occurred at %s:\n", e.position);
            System.err.println(e.getMessage());
            return 1;
        }

        return 0;
    }

    public static void main(String... args) {
        var exitCode = new CommandLine(new Main()).setCaseInsensitiveEnumValuesAllowed(true).execute(args);
        System.exit(exitCode);
    }
}