package de.thm.asc.generators.scanning.generator;

import de.thm.asc.tiel.interpreter.error.ScanningError;
import de.thm.asc.tiel.interpreter.scanning.TiELScanner;
import de.thm.asc.tiel.interpreter.scanning.Token;
import de.thm.asc.generators.scanning.automata.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static de.thm.asc.tiel.interpreter.scanning.TokenType.EOF;

public record FiniteAutomatonWithSemanticActions(
        FiniteAutomaton automaton,
        List<SemanticFinalState> semanticFinalStates
) {

    public record SemanticFinalState(State state, ScannerSpecification.Rule action) {
    }

    public TiELScanner asScanner() {
        if (!automaton.isDeterministic()) {
            throw new IllegalStateException("Cannot construct scanner from non-deterministic automaton");
        }

        var lookup = FastTransitionTable.construct(automaton);

        return new TiELScanner() {

            record Match(State state, int endIndex) {
            }

            private Optional<Match> findLongestMatch(String source, int start) {
                Match lastMatch = null;
                var state = automaton.initialState();

                var i = start;

                while (i < source.length()) {
                    var next = lookup.next(state, new Symbol(source.charAt(i)));

                    if (next.isEmpty()) break;
                    state = next.get();

                    i++;

                    if (automaton.finalStates().contains(state)) {
                        lastMatch = new Match(state, i);
                    }
                }

                return Optional.ofNullable(lastMatch);
            }

            @Override
            public List<Token> scan(String source) {
                var tokens = new ArrayList<Token>();

                var indexOfFirstCharacterNotConsumed = 0;
                var line = 1;
                var column = 1;

                while (indexOfFirstCharacterNotConsumed < source.length()) {
                    final var position = new Token.Position(line, column);

                    var match = findLongestMatch(source, indexOfFirstCharacterNotConsumed)
                            .orElseThrow(() -> new ScanningError("Unexpected character", position));

                    var matchedRule = semanticFinalStates.stream()
                            .filter(a -> a.state == match.state).findFirst()
                            .orElseThrow(() -> new IllegalStateException("Could not find rule for final state"));

                    var lexeme = source.substring(indexOfFirstCharacterNotConsumed, match.endIndex);

                    if (matchedRule.action.type() != null) {
                        Object literal = null;
                        if (matchedRule.action.transformer() != null) {
                            literal = matchedRule.action.transformer().apply(lexeme);
                        }

                        tokens.add(new Token(matchedRule.action.type(), lexeme, literal,
                                new Token.Position(line, column)));
                    }
                    var newLineCount = (int) lexeme.chars().boxed().filter(i -> i == '\n').count();
                    line += newLineCount;

                    if (newLineCount > 0) {
                        column = lexeme.length() - lexeme.lastIndexOf('\n');
                    } else {
                        column += lexeme.length();
                    }

                    indexOfFirstCharacterNotConsumed = match.endIndex;
                }

                tokens.add(new Token(EOF, "", null, new Token.Position(line, column)));

                return tokens;
            }
        };
    }
}
