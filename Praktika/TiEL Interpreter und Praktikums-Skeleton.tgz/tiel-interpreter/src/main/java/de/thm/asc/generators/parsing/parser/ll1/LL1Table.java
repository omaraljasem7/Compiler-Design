package de.thm.asc.generators.parsing.parser.ll1;

import de.thm.asc.generators.parsing.grammar.*;
import de.thm.asc.tiel.interpreter.util.MarkdownTable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The LL1Table is the parser table that powers LL1 parsing.
 * It is constructed using the first and follow sets of the underlying contextfree grammar.
 */
public class LL1Table {

    public final Grammar grammar;
    private final Map<CellID, Production> table;

    private LL1Table(Grammar grammar, Map<CellID, Production> table) {
        this.grammar = grammar;
        this.table = table;
    }

    public List<FollowSets.FollowElement> getExpectedForNonterminal(Symbol.NonTerminal nonTerminal) {
        return table.keySet().stream().filter(cell -> cell.nonterminal.equals(nonTerminal)).map(c -> c.terminal).toList();
    }

    public Production get(Symbol.NonTerminal nonterminal, FollowSets.FollowElement inputElement) {
        return this.table.get(new CellID(nonterminal, inputElement));
    }

    /**
     * Generates a Markdown table from this instance.
     *
     * @return The Markdown table.
     */
    public MarkdownTable toMarkdownTable() {
        var table = new MarkdownTable();
        var header = new MarkdownTable.Row().addCell("");

        for (var a : grammar.alphabet) {
            header.addCell(String.valueOf(a.value()));
        }
        header.addCell("$");

        table.setHeader(header);

        for (var n : grammar.nonTerminals) {
            var row = new MarkdownTable.Row();
            row.addCell(String.valueOf(n.value()));

            var symbols = new ArrayList<>(grammar.alphabet.stream().map(FollowSets.FollowElement::of).toList());
            symbols.add(FollowSets.FollowElement.DOLLAR);

            for (var a : symbols) {
                var p = get(n, a);
                if (p != null) {
                    var left = p.left().stream().map(Symbol::getRepresentation).collect(Collectors.joining(" "));
                    var right = p.right().stream().map(Symbol::getRepresentation).collect(Collectors.joining(" "));

                    /*
                        TODO: The use of String::length to determine the required column width does not account for
                              grapheme clusters. As a result, symbols that exceed UTF-16's 16-bit character size
                              may cause misalignment. For instance, ε.
                     */
                    row.addCell(String.format("%s -> %s", left, right));
                } else {
                    row.addCell("");
                }
            }

            table.addRow(row);
        }

        return table;
    }

    /**
     * Creates the LL1Table for the given grammar.
     *
     * @param grammar The grammar to construct a parser for. Must be LL1.
     * @return The constructed table. Null if the construction notices that the grammar is not LL1.
     */
    public static LL1Table constructForGrammar(Grammar grammar) {
        // LL1 tables can only be constructed for contextfree grammars, or this algorithm will fail.
        if (!grammar.type.get().isSubSetOf(GrammarType.TYPE2_CONTEXTFREE)) return null;

        var table = new HashMap<CellID, Production>();

        // TODO (Aufgabe 2): Implement the construction of the LL1 parsing table by filling the HashMap above.
        //                   Hint: Make sure you throw a descriptive error message when the algorithm detects that the grammar is not LL1. 

        return new LL1Table(grammar, table);
    }

    /**
     * A CellID identifies a single sell in the LL1 parsing table.
     * It is a pair of the nonterminal and an input symbol, which is either a terminal or the end of input marker $, which is why we use the {@link de.thm.asc.generators.parsing.grammar.FollowSets.FollowElement} class.
     *
     * @param nonterminal The nonterminal, aka the row of the cell.
     * @param terminal    The input element, aka the column of the cell.
     */
    private record CellID(Symbol.NonTerminal nonterminal, FollowSets.FollowElement terminal) {
    }
}


