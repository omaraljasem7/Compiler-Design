package de.thm.asc.tiel.interpreter.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * This is a utility class to create markdown formatted tables.
 */
public class MarkdownTable {

    public static class Row {

        private final List<String> cells = new ArrayList<>();

        public Row addCell(String value) {
            cells.add(value);
            return this;
        }
    }

    private Row header;
    private final List<Row> rows = new ArrayList<>();
    private int columns = -1;

    private int countEpsilons(String s) {
        return (s.length() - s.replace("ε", "").length()) / "ε".length();
    }

    private int[] calculateColumnWidths() {
        var widths = new int[columns];

        var clone = new ArrayList<>(rows);
        if (header != null) {
            clone.add(header);
        }

        for (var row : clone) {
            for (var i = 0; i < columns; i++) {
                var cell = row.cells.get(i);
                widths[i] = Math.max(widths[i], cell.length() - countEpsilons(cell));
            }
        }

        return widths;
    }

    private void applyColumns(Row row) {
        if (columns == -1) {
            columns = row.cells.size();
        } else if (columns != row.cells.size()) {
            throw new IllegalStateException("Inconsistent column width");
        }
    }

    public MarkdownTable addRow(Row row) {
        applyColumns(row);
        rows.add(row);

        return this;
    }

    public MarkdownTable setHeader(Row row) {
        applyColumns(row);
        header = row;

        return this;
    }

    private String padRight(String s, String c, int length) {
        return s + c.repeat(Math.max(0, length - s.length() + countEpsilons(s)));
    }

    private String joinRow(Row row, int[] widths) {
        return IntStream.range(0, columns)
                .mapToObj(i -> padRight(row.cells.get(i), " ", widths[i]))
                .collect(Collectors.joining(" | "));
    }

    @Override
    public String toString() {
        var sb = new StringBuilder();

        var columnWidths = calculateColumnWidths();

        if (header != null) {
            sb.append("| ");
            sb.append(joinRow(header, columnWidths));
            sb.append(String.format(" |%n"));
            for (var w : columnWidths) {
                sb.append(String.format("|%s", "-".repeat(w + 2)));
            }
            sb.append(String.format("|%n"));
        }

        for (var r : rows) {
            sb.append("| ");
            sb.append(joinRow(r, columnWidths));
            sb.append(String.format(" |%n"));
        }

        return sb.toString();
    }
}

