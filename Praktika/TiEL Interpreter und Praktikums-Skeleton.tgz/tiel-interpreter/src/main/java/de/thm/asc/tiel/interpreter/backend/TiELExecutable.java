package de.thm.asc.tiel.interpreter.backend;

import de.thm.asc.tiel.interpreter.backend.common.Environment;

public abstract class TiELExecutable {
    public abstract void executeIn(Environment env);

    void execute() {
        this.executeIn(new Environment());
    }
}
