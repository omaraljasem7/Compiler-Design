package de.thm.asc.teir;

import de.thm.asc.tiel.interpreter.ast.AstPrinter;
import de.thm.asc.tiel.interpreter.ast.expr.Expr;
import de.thm.asc.tiel.interpreter.ast.stmt.Stmt;
import de.thm.asc.tiel.interpreter.backend.common.TiELValue;

public sealed interface StackInstruction {

    record PushC(TiELValue value) implements StackInstruction {}
    record Pop() implements StackInstruction {}
    record Dup() implements StackInstruction {}
    record Add() implements StackInstruction {}
    record Mul() implements StackInstruction {}
    record Sub() implements StackInstruction {}
    record Div() implements StackInstruction {}
    record LT() implements StackInstruction {}
    record GT() implements StackInstruction {}
    record LE() implements StackInstruction {}
    record EQ() implements StackInstruction {}
    record NE() implements StackInstruction {}
    record GE() implements StackInstruction {}
    record OpenFrame() implements StackInstruction {}
    record CreateVar(String name) implements StackInstruction {}
    record PushVar(String name) implements StackInstruction {}
    record SetVar(String name) implements StackInstruction {}
    record CloseFrame() implements StackInstruction {}
    record Label(String name) implements StackInstruction {}
    record Jmp(String label) implements StackInstruction {}
    record JmpIfTruthy(String label) implements StackInstruction {}
    record JmpIfFalsy(String label) implements StackInstruction {}
    record Call() implements StackInstruction {}
    record Return() implements StackInstruction {}
    record CreateClosure(String label) implements StackInstruction {}
    record TiELInterpretedExpressionFallback(Expr expr) implements StackInstruction {}
    record TiELInterpretedStatementFallback(Stmt stmt) implements StackInstruction {}

    static String prettyPrint(StackInstruction instruction) {
        return switch (instruction) {
            case Add ins -> "add";
            case Call ins -> "call";
            case CloseFrame ins -> "closeframe";
            case CreateClosure ins -> "createclosure " + ins.label;
            case CreateVar ins -> "createvar " + ins.name;
            case Div ins -> "div";
            case Dup ins -> "dup";
            case EQ ins -> "eq";
            case GE ins -> "ge";
            case GT ins -> "gt";
            case Jmp ins -> "jmp " + ins.label;
            case JmpIfFalsy ins -> "jmpiffalsy " + ins.label;
            case JmpIfTruthy ins -> "jmpiftruthy " + ins.label;
            case LE ins -> "le";
            case LT ins -> "lt";
            case Label ins -> ins.name + ":";
            case Mul ins -> "mul";
            case NE ins -> "ne";
            case OpenFrame ins -> "openframe";
            case Pop ins -> "pop";
            case PushC ins -> "pushc " + ins.value;
            case PushVar ins -> "pushvar " + ins.name;
            case Return ins -> "return";
            case SetVar ins -> "setvar " + ins.name;
            case Sub ins -> "sub";
            case TiELInterpretedExpressionFallback ins -> "<interpreted expression fallback %s>".formatted(new AstPrinter().print(ins.expr()));
            case TiELInterpretedStatementFallback ins -> "<interpreted statement fallback %s>".formatted(new AstPrinter().print(ins.stmt));
        };
    }
}
