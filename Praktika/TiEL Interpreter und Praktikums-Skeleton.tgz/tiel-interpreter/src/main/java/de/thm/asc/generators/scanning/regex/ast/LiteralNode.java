package de.thm.asc.generators.scanning.regex.ast;

/**
 * Literal nodes describe singular characters in a regular expression, such as `a`.
 */
public final class LiteralNode extends RegularExpression {

    public final char value;

    @Override
    protected int getPrecedence() {
        return Integer.MAX_VALUE;
    }

    public LiteralNode(final char value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
