package de.thm.asc.tiel.interpreter.parsing;

import de.thm.asc.tiel.interpreter.ast.stmt.Stmt;
import de.thm.asc.tiel.interpreter.scanning.Token;

import java.util.List;

/**
 * A parser has the ability to find a derivation tree for an input string and an underlying grammar.
 */
public interface TiELParser {

    /**
     * Parses the given string.
     *
     * @param tokens The list of tokens to parse..
     * @return A derivation tree for this input. Null if it could not be parsed.
     */
    List<Stmt> parse(List<Token> tokens);
}

