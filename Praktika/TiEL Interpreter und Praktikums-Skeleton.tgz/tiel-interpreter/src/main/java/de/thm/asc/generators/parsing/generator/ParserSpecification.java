package de.thm.asc.generators.parsing.generator;

import de.thm.asc.generators.parsing.grammar.Grammar;
import de.thm.asc.generators.parsing.grammar.Production;
import de.thm.asc.generators.parsing.grammar.Symbol;
import de.thm.asc.generators.parsing.parser.DerivationTree;
import de.thm.asc.generators.parsing.parser.ll1.LL1Automaton;
import de.thm.asc.generators.parsing.parser.ll1.LL1Table;
import de.thm.asc.generators.scanning.generator.ScannableTokenType;
import de.thm.asc.tiel.interpreter.ast.Positionable;
import de.thm.asc.tiel.interpreter.scanning.Token;

import java.util.*;
import java.util.stream.Collectors;

public record ParserSpecification(Grammar grammar, Map<Production, SemanticAction> semanticActions) {

    public Object generateAst(DerivationTree.Node node) {
        var semanticAction = semanticActions.get(node.getProduction());

        if (node.children == null) {
            return node.token;
        }

        if (semanticAction == null) {
            return null;
        }

        var generatedChildren = node.children.stream().map(this::generateAst).toList();
        var values = generatedChildren.stream().map(o -> {
            if (o instanceof Token t) {
                return t.value();
            }

            return o;
        }).toList();

        var r = semanticAction.apply(new SemanticAction.Values(values));

        if (r instanceof Positionable<?> thisPositionable) {
            var anchor = generatedChildren.getFirst();
            if (anchor instanceof Token t) {
                return thisPositionable.withPosition(t.position());
            } else if (anchor instanceof Positionable<?> childPositionable) {
                return thisPositionable.withPosition(childPositionable.getPosition());
            }
        }

        return r;
    }

    public LL1Automaton getParser() {
        return new LL1Automaton(LL1Table.constructForGrammar(grammar));
    }

    public static class Builder {

        private final Class<? extends ScannableTokenType> tokenType;
        private final Set<Symbol.NonTerminal> nonTerminals = new HashSet<>();
        private final Set<Production> productions = new HashSet<>();
        private Symbol.NonTerminal startSymbol = null;
        private final Map<Production, SemanticAction> semanticActions = new HashMap<>();

        public Builder(Class<? extends ScannableTokenType> tokenType) {
            this.tokenType = tokenType;
        }

        public class NonTerminalSpecification implements ParseableSymbol {

            public final Symbol.NonTerminal nonTerminal;

            public NonTerminalSpecification(Symbol.NonTerminal nonTerminal) {
                this.nonTerminal = nonTerminal;
            }

            public ProductionSpecification produces(ParseableSymbol... symbols) {
                var right = Arrays.stream(symbols).map(ParseableSymbol::getUnderlyingSymbol).toList();

                var production = new Production(List.of(nonTerminal), right);

                productions.add(production);

                if (symbols.length == 1) {
                    semanticActions.put(production, SemanticAction.passthrough());
                }

                return new ProductionSpecification(production);
            }

            @Override
            public Symbol getUnderlyingSymbol() {
                return nonTerminal;
            }
        }

        public class ProductionSpecification {

            private final Production production;

            ProductionSpecification(Production production) {
                this.production = production;
            }

            public void withSemantic(SemanticAction semanticAction) {
                semanticActions.put(production, semanticAction);
            }

            public void withSemantic(Class<?> clazz) {
                semanticActions.put(production, SemanticAction.fromClass(clazz));
            }
        }

        public void startSymbol(NonTerminalSpecification symbol) {
            startSymbol = symbol.nonTerminal;
        }

        public NonTerminalSpecification nonTerminal(String name) {
            var nt = new Symbol.NonTerminal(name);
            nonTerminals.add(nt);

            return new NonTerminalSpecification(nt);
        }

        public ParserSpecification getSpecification() {
            var terminals = Arrays.stream(tokenType.getEnumConstants())
                    .map(Symbol.Terminal::new)
                    .collect(Collectors.toSet());

            return new ParserSpecification(
                    new Grammar(nonTerminals, terminals, productions, startSymbol),
                    this.semanticActions
            );
        }
    }
}
