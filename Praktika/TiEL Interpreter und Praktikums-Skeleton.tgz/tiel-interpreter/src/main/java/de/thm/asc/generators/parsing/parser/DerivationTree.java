package de.thm.asc.generators.parsing.parser;

import de.thm.asc.generators.parsing.grammar.Grammar;
import de.thm.asc.generators.parsing.grammar.Production;
import de.thm.asc.generators.parsing.grammar.Symbol;
import de.thm.asc.tiel.interpreter.scanning.Token;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class DerivationTree {
    public final Grammar underlyingGrammar;

    private int derivationCounter = 0;
    private final Node root;

    public DerivationTree(Grammar underlyingGrammar) {
        this.underlyingGrammar = underlyingGrammar;

        this.root = createNode(underlyingGrammar.startSymbol);
    }

    /**
     * @return The current root node of this derivation tree. May be null.
     */
    public Node getRoot() {
        return root;
    }

    /**
     * Gets the derivation from this derivation tree. Derivation order is determined by the internally tracked derivation indices.
     *
     * @return The derivation sequence that created this derivation tree.
     */
    public Derivation getDerivation() {
        if (root == null)
            throw new IllegalStateException("Cannot get derivation from a derivation tree without a root node.");

        var steps = new ArrayList<List<Symbol>>();

        var current = List.of(root);

        steps.add(current.stream().map(n -> n.symbol).toList());

        while (current.stream().anyMatch(Node::isDerivedNonterminal)) {
            var min = current.stream().filter(Node::isDerivedNonterminal).mapToInt(n -> n.derivationIndex).min().getAsInt();

            current = current.stream().flatMap(c ->
                    Objects.equals(c.derivationIndex, min)
                            ? c.children.stream()
                            : Stream.of(c)
            ).toList();

            steps.add(current.stream().map(n -> n.symbol).toList());
        }

        return new Derivation(steps);
    }

    /**
     * @return True if this derivation tree has no underived nonterminal nodes left.
     */
    boolean isFullyDerived() {
        return root != null && root.isFullyDerived();
    }

    /**
     * @return The current symbol string described by the terminal and underived nonterminal nodes of this tree.
     */
    public List<Symbol> getSymbolString() {
        if (root == null) return List.of();

        var list = new ArrayList<Symbol>();

        // The symbol string is found by a left to right traversal of the tree.
        root.forEachPreOrder(node -> {
            if (node.isTerminal() || node.isUnderivedNonterminal()) list.add(node.symbol);
        });

        return list;
    }

    /**
     * Creates a new derivation tree node for the given symbol.
     *
     * @param symbol A symbol.
     * @return The created tree node.
     */
    public Node createNode(Symbol symbol) {
        return new Node(symbol);
    }

    /**
     * Converts this derivation tree to GraphViz dot code.
     *
     * @return The generated dot code.
     */
    public String toDotCode() {
        var sb = new StringBuilder();
        sb.append("digraph Tree {").append(System.lineSeparator());
        sb.append("\tnode [shape=circle, style=filled, color=lightblue];")
                .append(System.lineSeparator())
                .append(System.lineSeparator());

        sb.append(String.format(
                "\t\"%s\" [label=\"%s\"]%n",
                root.symbol.getRepresentation() + "_" + root.derivationIndex,
                root.symbol.getRepresentation()
        ));

        root.appendDotCode(sb);

        sb.append("}");

        return sb.toString();
    }

    public class Node {
        public final Symbol symbol;
        private Production production;
        public List<Node> children = null;
        public Token token = null;
        private Integer derivationIndex = null;

        Node(Symbol symbol) {
            this.symbol = symbol;
        }

        /**
         * @return Whether the subtree described by this node is fully derived. A derivation tree node is fully if it contains no underived nonterminal nodes anywhere.
         */
        public boolean isFullyDerived() {
            return isTerminal() || (isDerivedNonterminal() && children.stream().allMatch(Node::isFullyDerived));
        }

        /**
         * @return True if this node is a terminal node.
         */
        public boolean isTerminal() {
            return symbol instanceof Symbol.Terminal;
        }

        /**
         * @return Whether this node is a nonterminal node without defined children.
         */
        public boolean isUnderivedNonterminal() {
            return symbol instanceof Symbol.NonTerminal && children == null;
        }

        /**
         * @return Whether this node is a nonterminal node with defined children.
         */
        public boolean isDerivedNonterminal() {
            return children != null;
        }

        /**
         * Sets the derivation for an underived nonterminal node.
         *
         * @param children The list of children nodes to set.
         * @return The same list of children nodes.
         * @throws IllegalStateException if this node is a terminal node or a nonterminal node that already has a derivation.
         */
        public List<Node> setDerivation(List<Node> children) {
            if (isTerminal()) throw new IllegalStateException("Cannot set derivation for terminal nodes.");
            if (derivationIndex != null)
                throw new IllegalStateException("Cannot set derivation of an already derived nonterminal node.");

            derivationIndex = derivationCounter++;

            return this.children = children;
        }

        public void setToken(Token token) {
            if (!isTerminal()) throw new IllegalStateException("Cannot set token for non terminal nodes.");
            if (this.token != null) throw new IllegalStateException("Cannot set token for a node that already has a token.");

            this.token = token;
        }

        public void setProduction(Production production) {
            this.production = production;
        }

        public Production getProduction() {
            return production;
        }

        /**
         * Traverses the tree described by this node in a preorder fashion, calling the supplied function for each node.
         *
         * @param f The function to apply to each node.
         */
        void forEachPreOrder(Consumer<Node> f) {
            f.accept(this);

            if (children != null) children.forEach(c -> c.forEachPreOrder(f));
        }

        /**
         * Appends dot code of this node to the given StringBuilder.
         *
         * @param sb The StringBuilder to append to.
         */
        void appendDotCode(StringBuilder sb) {
            if (children == null) {
                return;
            }

            var labelIndex = 0;

            for (var c : children) {
                sb.append(String.format(
                        "\t\"%s\" -> \"%s\";%n",
                        symbol.getRepresentation() + "_" + derivationIndex,
                        c.isTerminal()
                                ? c.symbol.getRepresentation() + "_" + derivationIndex + "_" + labelIndex
                                : c.symbol.getRepresentation() + "_" + c.derivationIndex
                ));
                if (c.isTerminal()) {
                    sb.append(String.format("\t\"%s\" [color=gold, label=\"%s\"]%n",
                            c.symbol.getRepresentation() + "_" + derivationIndex + "_" + labelIndex, c.symbol.getRepresentation()));
                } else {
                    sb.append(String.format("\t\"%s\" [label=\"%s\"]%n",
                            c.symbol.getRepresentation() + "_" + c.derivationIndex, c.symbol.getRepresentation()));
                }
                c.appendDotCode(sb);
                labelIndex++;
            }
        }
    }
}

