package de.thm.asc.generators.scanning.generator;

import de.thm.asc.generators.scanning.automata.State;
import de.thm.asc.generators.scanning.automata.Transition;
import de.thm.asc.generators.scanning.regex.ThompsonsConstruction;

import java.util.ArrayList;

public class ScannerThompsonsConstruction extends ThompsonsConstruction {

    public static FiniteAutomatonWithSemanticActions construct(ScannerSpecification scanner) {

        var instance = new ScannerThompsonsConstruction();

        var entryStates = new ArrayList<State>();

        var semanticFinalStates = scanner.rules().stream().map(rule -> {
            var partialAutomaton = instance.generate(rule.regex());

            entryStates.add(partialAutomaton.entry());
            instance.builder.makeFinalState(partialAutomaton.exit());

            return new FiniteAutomatonWithSemanticActions.SemanticFinalState(partialAutomaton.exit(), rule);
        }).toList();

        var initialState = instance.builder.newState();

        for (var entry : entryStates) {
            instance.builder.addTransition(Transition.newEpsilonTransition(initialState, entry));
        }

        instance.builder.setInitialState(initialState);

        return new FiniteAutomatonWithSemanticActions(instance.builder.result(), semanticFinalStates);
    }
}