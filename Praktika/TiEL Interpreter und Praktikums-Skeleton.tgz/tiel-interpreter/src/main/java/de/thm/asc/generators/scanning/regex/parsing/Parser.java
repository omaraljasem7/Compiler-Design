package de.thm.asc.generators.scanning.regex.parsing;

import de.thm.asc.generators.scanning.regex.parsing.Lexer.*;
import de.thm.asc.generators.scanning.regex.ast.*;

import java.util.ArrayList;
import java.util.List;

class Parser {

    private final Lexer lexer;
    private Lexer.Token currentToken;

    public Parser(Lexer lexer) {
        this.lexer = lexer;

        nextToken();
    }

    private void nextToken() {
        currentToken = lexer.nextToken();

        if (currentToken.type() == TokenType.ILLEGAL) {
            error(String.format("Illegal token: %s", currentToken));
        }
    }

    private void error(String message) {
        throw new RuntimeException(String.format("Error: %s%n", message));
    }

    private void expectToken(Lexer.TokenType expected) {
        if (currentToken.type() != expected) {
            error(String.format("Unexpected token `%s`, expected `%s`.", currentToken.type(), expected));
        }

        nextToken();
    }

    RegularExpression parse() {
        return parseAlternation();
    }

    private RegularExpression parseAlternation() {
        var left = parseConcatenation();

        while (currentToken.type() == TokenType.PIPE) {
            expectToken(TokenType.PIPE);
            var right = parseConcatenation();

            left = new AlternationNode(left, right);
        }

        return left;
    }

    private RegularExpression parseConcatenation() {
        if (currentToken.type() == TokenType.R_PAREN || currentToken.type() == TokenType.PIPE
                || currentToken.type() == TokenType.EOF) {
            return new EmptyNode();
        }

        var left = parseRepetition();

        while (currentToken.type() == TokenType.LITERAL || currentToken.type() == TokenType.L_PAREN
                || currentToken.type() == TokenType.L_BRACK) {
            var right = parseRepetition();

            left = new ConcatenationNode(left, right);
        }

        return left;
    }

    private RegularExpression parseRepetition() {
        var left = parseFactor();

        switch (currentToken.type()) {
            case ASTERISK -> {
                expectToken(TokenType.ASTERISK);
                return new RepetitionNode(left, true);
            }
            case PLUS -> {
                expectToken(TokenType.PLUS);
                return new RepetitionNode(left, false);
            }
            case QUESTION_MARK -> {
                expectToken(TokenType.QUESTION_MARK);
                return new AlternationNode(left, new EmptyNode());
            }
        }

        return left;
    }

    private RegularExpression parseFactor() {
        return switch (currentToken.type()) {
            case LITERAL -> parseLiteral();
            case DOT -> {
                expectToken(TokenType.DOT);
                var lowerRange = new CharacterClassNode.Range((char) 0x0, (char) 0x9);
                var upperRange = new CharacterClassNode.Range((char) 0xb, (char) 0x7f);

                yield new CharacterClassNode(List.of(lowerRange, upperRange));
            }
            case L_PAREN -> {
                expectToken(TokenType.L_PAREN);
                var group = parse();
                expectToken(TokenType.R_PAREN);

                yield group;
            }
            case L_BRACK -> {
                expectToken(TokenType.L_BRACK);
                var characterClass = parseCharacterClass();
                expectToken(TokenType.R_BRACK);

                yield characterClass;
            }
            case EOF -> new EmptyNode();
            default -> {
                error(String.format("Unexpected token: %s", currentToken));

                yield null; // unreachable
            }
        };
    }

    private LiteralNode parseLiteral() {
        var literal = new LiteralNode(currentToken.literal().charAt(0));
        expectToken(TokenType.LITERAL);

        return literal;
    }

    private RegularExpression parseCharacterClass() {
        var elements = new ArrayList<CharacterClassNode.Range>();

        while (currentToken.type() == TokenType.LITERAL) {
            var leftLiteral = parseLiteral();

            if (currentToken.type() == TokenType.MINUS) {
                expectToken(TokenType.MINUS);
                var rightLiteral = parseLiteral();
                elements.add(new CharacterClassNode.Range(leftLiteral.value, rightLiteral.value));
            } else {
                elements.add(new CharacterClassNode.Range(leftLiteral.value, leftLiteral.value));
            }
        }

        if (elements.isEmpty()) {
            error("Character class may not be empty");
        }

        return new CharacterClassNode(elements);
    }
}
