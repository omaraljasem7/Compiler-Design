package de.thm.asc.generators.parsing.grammar;

public enum GrammarType {

    TYPE0_FREE,
    TYPE1_CONTEXTSENSITIVE,
    TYPE1_MONOTONE,
    TYPE2_CONTEXTFREE,
    TYPE3_RIGHTREGULAR,
    TYPE3_LEFTREGULAR;

    /**
     * @return The level of the language produced by grammars of this type on the chomsky hierarchy.
     */
    public int levelOnChomskyHierarchy() {
        return switch (this) {
            case TYPE0_FREE -> 0;
            case TYPE1_CONTEXTSENSITIVE -> 1;
            case TYPE2_CONTEXTFREE -> 2;
            case TYPE1_MONOTONE -> 1;
            case TYPE3_RIGHTREGULAR -> 3;
            case TYPE3_LEFTREGULAR -> 3;
        };
    }

    /**
     * @param other Another GrammarType.
     * @return Whether this grammar type contains all grammars of the other type.
     */
    public boolean isSuperSetOf(GrammarType other) {
        return switch (this) {
            case TYPE0_FREE -> true;
            case TYPE1_CONTEXTSENSITIVE -> other == TYPE1_CONTEXTSENSITIVE || other.levelOnChomskyHierarchy() >= 2;
            case TYPE1_MONOTONE -> other == TYPE1_MONOTONE || other.levelOnChomskyHierarchy() >= 2;
            case TYPE2_CONTEXTFREE -> other.levelOnChomskyHierarchy() >= 2;
            case TYPE3_RIGHTREGULAR -> other == TYPE3_RIGHTREGULAR;
            case TYPE3_LEFTREGULAR -> other == TYPE3_LEFTREGULAR;
        };
    }

    @Override
    public String toString() {
        return switch (this) {
            case TYPE0_FREE -> "Free";
            case TYPE1_CONTEXTSENSITIVE -> "Context-sensitive";
            case TYPE1_MONOTONE -> "Monotone";
            case TYPE2_CONTEXTFREE -> "Context-free";
            case TYPE3_RIGHTREGULAR -> "Right-regular";
            case TYPE3_LEFTREGULAR -> "Left-regular";
        };
    }

    /**
     * @param other Another GrammarType.
     * @return Whether all grammars of this grammar type are also of the other given type.
     */
    public boolean isSubSetOf(GrammarType other) {
        return other.isSuperSetOf(this);
    }
}

