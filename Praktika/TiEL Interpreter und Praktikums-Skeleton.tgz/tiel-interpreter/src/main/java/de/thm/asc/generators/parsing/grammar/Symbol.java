package de.thm.asc.generators.parsing.grammar;

import de.thm.asc.generators.scanning.generator.ScannableTokenType;
import de.thm.asc.tiel.interpreter.scanning.TokenType;

/**
 * Represents a symbol of a grammar. A symbol may either be a Terminal or Non-Terminal.
 */
public sealed interface Symbol {

    String getRepresentation();

    /**
     * Represents a terminal symbol of a grammar (usually represented by a lowercase letter).
     *
     * @param value The name of the symbol.
     */
    record Terminal(ScannableTokenType value) implements Symbol {

        @Override
        public String getRepresentation() {
            return String.valueOf(value);
        }
    }

    /**
     * Represents a non-terminal symbol of a grammar (usually represented by an uppercase letter).
     *
     * @param value The name of the symbol.
     */
    record NonTerminal(String value) implements Symbol {

        @Override
        public String getRepresentation() {
            return String.valueOf(value);
        }
    }
}


