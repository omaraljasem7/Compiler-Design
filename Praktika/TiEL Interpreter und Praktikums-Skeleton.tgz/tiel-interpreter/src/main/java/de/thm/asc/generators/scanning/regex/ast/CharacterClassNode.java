package de.thm.asc.generators.scanning.regex.ast;

import java.util.List;

public final class CharacterClassNode extends RegularExpression {
    public final List<Range> ranges;

    public CharacterClassNode(List<Range> ranges) {
        this.ranges = ranges;
    }

    @Override
    protected int getPrecedence() {
        throw new RuntimeException("Not yet implemented");
    }

    @Override
    public String toString() {
        throw new RuntimeException("Not yet implemented");
    }

    public record Range(Character lower, Character upper) {}
}
