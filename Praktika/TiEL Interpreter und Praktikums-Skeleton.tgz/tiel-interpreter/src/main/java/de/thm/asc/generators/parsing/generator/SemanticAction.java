package de.thm.asc.generators.parsing.generator;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public interface SemanticAction extends Function<SemanticAction.Values, Object> {

    record Values(List<Object> values) {

        public <T> T get(int index) {
            return (T) values.get(index);
        }
    }

    static SemanticAction fromClass(Class<?> clazz) {
        return $ -> {
            var children = $.values.stream().filter(Objects::nonNull).toList();
            var args = children.toArray();

            try {
                return clazz.getConstructors()[0].newInstance(args);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        };
    }

    static SemanticAction passthrough() {
        return $ -> {
            var children = $.values.stream().filter(Objects::nonNull).toList();

            if (children.size() == 1) {
                return children.getFirst();
            } else {
                return null;
            }
        };
    }
}
