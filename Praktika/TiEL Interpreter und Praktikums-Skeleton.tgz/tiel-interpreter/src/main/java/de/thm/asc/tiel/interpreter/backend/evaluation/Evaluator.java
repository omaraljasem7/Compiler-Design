package de.thm.asc.tiel.interpreter.backend.evaluation;

import de.thm.asc.tiel.interpreter.ast.expr.*;
import de.thm.asc.tiel.interpreter.ast.stmt.*;
import de.thm.asc.tiel.interpreter.backend.common.Common;
import de.thm.asc.tiel.interpreter.backend.common.Environment;
import de.thm.asc.tiel.interpreter.backend.common.TiELCallable;
import de.thm.asc.tiel.interpreter.backend.common.TiELValue;
import de.thm.asc.tiel.interpreter.error.RuntimeError;
import de.thm.asc.tiel.interpreter.scanning.Token;

import java.util.ArrayList;
import java.util.List;

/**
 * The Evaluator class interprets and executes TiEL language expressions and statements.
 * It maintains an execution environment and supports variable resolution, function calls,
 * and basic control flow operations.
 */
public class Evaluator {

    /**
     * The current execution environment, initially set to the global environment.
     */
    private final Environment environment;

    /**
     * Constructs an Evaluator and defines built-in functions.
     */
    public Evaluator(Environment environment) {
        this.environment = environment;
    }

    /**
     * Interprets a list of statements by executing them sequentially.
     *
     * @param statements The statements to interpret.
     */
    public void interpret(List<Stmt> statements) {
        for (var s : statements) {
            execute(s);
        }
    }

    /**
     * Evaluates an expression.
     *
     * @param expr The expression to evaluate.
     * @return The evaluated value-
     */
    public TiELValue evaluate(Expr expr) {

        return switch (expr) {
            case AssignExpr assignExpr -> {
                var value = evaluate(assignExpr.value);

                environment.assign(assignExpr.name, value, assignExpr.getPosition());

                yield value;
            }
            case BinaryExpr binaryExpr -> {
                var left = evaluate(binaryExpr.left);
                var right = evaluate(binaryExpr.right);

                yield switch (binaryExpr.operator) {
                    case EQ -> Common.wrap(left.equals(right));
                    case NEQ -> Common.wrap(!left.equals(right));
                    case LT -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() < ((TiELValue.TNumber) right).value());
                    }
                    case LE -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() <= ((TiELValue.TNumber) right).value());
                    }
                    case GT -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() > ((TiELValue.TNumber) right).value());
                    }
                    case GE -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() >= ((TiELValue.TNumber) right).value());
                    }
                    case SUB -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() - ((TiELValue.TNumber) right).value());
                    }
                    case ADD -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() + ((TiELValue.TNumber) right).value());
                    }
                    case DIV -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() / ((TiELValue.TNumber) right).value());
                    }
                    case MUL -> {
                        checkNumberOperands(binaryExpr.operator, left, right, binaryExpr.getPosition());
                        yield Common.wrap(((TiELValue.TNumber) left).value() * ((TiELValue.TNumber) right).value());
                    }
                    default -> null; // Unreachable;
                };
            }
            case CallExpr callExpr -> {
                var callee = evaluate(callExpr.callee);

                var arguments = new ArrayList<TiELValue>();
                for (var argument : callExpr.arguments) {
                    arguments.add(evaluate(argument));
                }

                if (!(callee instanceof TiELCallable function)) {
                    throw new RuntimeError("Can only call functions.", callExpr.getPosition());
                }

                if (arguments.size() != function.arity()) {
                    throw new RuntimeError(
                            String.format("Expected %s arguments but got %s.", function.arity(), arguments.size()),
                            callExpr.getPosition()
                    );
                }

                yield function.call(arguments, callExpr.getPosition());
            }
            case LiteralExpr literalExpr -> literalExpr.value;
            case LogicalExpr logicalExpr -> {
                var left = evaluate(logicalExpr.left);

                if (logicalExpr.operator == LogicalExpr.Operator.OR) {
                    if (Common.isTruthy(left)) yield left;
                } else {
                    if (!Common.isTruthy(left)) yield left;
                }

                yield evaluate(logicalExpr.right);
            }
            case UnaryExpr unaryExpr -> {
                var right = evaluate(unaryExpr.right);

                yield switch (unaryExpr.operator) {
                    case NOT -> Common.wrap(!Common.isTruthy(right));
                    case MINUS -> {
                        checkNumberOperand(unaryExpr.operator, right, unaryExpr.getPosition());
                        yield Common.wrap(-((TiELValue.TNumber) right).value());
                    }
                };
            }
            case VariableExpr variableExpr -> environment.get(variableExpr.name, variableExpr.getPosition());
        };
    }

    /**
     * Executes a statement.
     *
     * @param stmt The statement to execute.
     */
    public void execute(Stmt stmt) {
        switch (stmt) {
            case BlockStmt blockStmt -> new Evaluator(new Environment(environment)).interpret(blockStmt.statements);
            case ExpressionStmt expressionStmt -> evaluate(expressionStmt.expression);
            case FunctionDeclStmt functionDeclStmt -> {
                var function = new TiELFunction(functionDeclStmt, environment);

                environment.define(functionDeclStmt.name, function, functionDeclStmt.getPosition());
            }
            case IfStmt ifStmt -> {
                if (Common.isTruthy(evaluate(ifStmt.condition))) {
                    execute(ifStmt.thenBranch);
                } else if (ifStmt.elseBranch != null) {
                    execute(ifStmt.elseBranch);
                }
            }
            case ReturnStmt returnStmt -> {
                TiELValue value = TiELValue.NIL;
                if (returnStmt.value != null) value = evaluate(returnStmt.value);

                throw new ReturnException(value);
            }
            case VarDeclStmt varDeclStmt -> {
                var value = evaluate(varDeclStmt.initializer);

                environment.define(varDeclStmt.name, value, varDeclStmt.getPosition());
            }
            case WhileStmt whileStmt -> {
                while (Common.isTruthy(evaluate(whileStmt.condition))) {
                    execute(whileStmt.body);
                }
            }
        }
    }

    /**
     * Ensures that two operands are numbers, throwing an error if not.
     *
     * @param operator      The operator token.
     * @param left          The left operand.
     * @param right         The right operand.
     * @param errorPosition The position at which an error will be thrown.
     */
    private void checkNumberOperands(BinaryExpr.Operator operator, TiELValue left, TiELValue right, Token.Position errorPosition) {
        if (left instanceof TiELValue.TNumber && right instanceof TiELValue.TNumber) return;
        throw new RuntimeError(String.format("Operands to '%s' must be numbers.", operator.toString()), errorPosition);
    }


    /**
     * Ensures that an operand is a number, throwing an error if not.
     *
     * @param operator The operator token.
     * @param operand  The operand.
     * @param errorPosition The position at which an error will be thrown.
     */
    private void checkNumberOperand(UnaryExpr.Operator operator, TiELValue operand, Token.Position errorPosition) {
        if (operand instanceof TiELValue.TNumber) return;
        throw new RuntimeError(String.format("Operand to '%s' must be a number.", operator.toString()), errorPosition);
    }
}
