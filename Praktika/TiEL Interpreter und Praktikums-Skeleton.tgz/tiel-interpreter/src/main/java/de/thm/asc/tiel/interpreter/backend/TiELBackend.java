package de.thm.asc.tiel.interpreter.backend;

import de.thm.asc.teir.TeIRVirtualMachine;
import de.thm.asc.tiel.interpreter.ast.stmt.Stmt;
import de.thm.asc.tiel.interpreter.backend.codegeneration.CodeGenerator;
import de.thm.asc.tiel.interpreter.backend.common.Environment;
import de.thm.asc.tiel.interpreter.backend.evaluation.Evaluator;

import java.util.List;

public abstract class TiELBackend {
    public abstract TiELExecutable build(List<Stmt> program);

    public static TiELBackend interpreterBackend() {
        return new TiELBackend() {
            @Override
            public TiELExecutable build(List<Stmt> program) {
                return new TiELExecutable() {
                    @Override
                    public void executeIn(Environment env) {
                        new Evaluator(env).interpret(program);
                    }
                };
            }
        };
    }

    public static TiELBackend teirVMBackend() {
        return new TiELBackend() {
            @Override
            public TiELExecutable build(List<Stmt> program) {
                var listing = CodeGenerator.generate(program);

                return new TiELExecutable() {
                    @Override
                    public void executeIn(Environment env) {
                        new TeIRVirtualMachine(env, listing).run();
                    }
                };
            }
        };
    }
}
