package de.thm.asc.generators.parsing.grammar;

import de.thm.asc.tiel.interpreter.util.LazyValue;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Grammar {

    public final Set<Symbol.NonTerminal> nonTerminals;
    public final Set<Symbol.Terminal> alphabet;
    public final Set<Production> productions;
    public final Symbol.NonTerminal startSymbol;

    // lazily computed data about this grammar
    public final LazyValue<FirstSets> firstSets = new LazyValue<>(() -> new FirstSets(this));
    public final LazyValue<FollowSets> followSets = new LazyValue<>(() -> new FollowSets(this));
    public final LazyValue<GrammarType> type = new LazyValue<>(this::calculateType);

    /**
     * @param nonTerminals The set containing all non-terminal symbols of the grammar.
     * @param alphabet     The set containing the alphabet of the grammar.
     * @param productions  The set containing all productions of the grammar.
     * @param startSymbol  The start symbol of the grammar.
     */
    public Grammar(Set<Symbol.NonTerminal> nonTerminals,
                   Set<Symbol.Terminal> alphabet,
                   Set<Production> productions,
                   Symbol.NonTerminal startSymbol) {
        this.nonTerminals = nonTerminals;
        this.alphabet = alphabet;
        this.productions = productions;
        this.startSymbol = startSymbol;
    }

    /**
     * Determines the type of this grammar on the chomsky hierarchy.
     * Prefer to use {@link Grammar#type} for a lazily computed version of this.
     */
    private GrammarType calculateType() {
        // Check for right regularity
        if (this.productions.stream().allMatch(production ->
                production.left().size() == 1 && production.left().getFirst() instanceof Symbol.NonTerminal
                        && (production.right().isEmpty()
                        || production.right().size() == 1 && production.right().getFirst() instanceof Symbol.NonTerminal
                        || production.right().size() == 2 && production.right().getFirst() instanceof Symbol.NonTerminal
                        && production.right().get(1) instanceof Symbol.Terminal)
        )) return GrammarType.TYPE3_RIGHTREGULAR;

        // Check for left regularity
        if (this.productions.stream().allMatch(production ->
                production.left().size() == 1 && production.left().getFirst() instanceof Symbol.NonTerminal
                        && (production.right().isEmpty()
                        || production.right().size() == 1 && production.right().getFirst() instanceof Symbol.NonTerminal
                        || production.right().size() == 2 && production.right().getFirst() instanceof Symbol.Terminal
                        && production.right().get(1) instanceof Symbol.NonTerminal)
        )) return GrammarType.TYPE3_LEFTREGULAR;

        // Check for context free
        if (this.productions.stream().allMatch(production ->
                production.left().size() == 1 && production.left().getFirst() instanceof Symbol.NonTerminal
        )) return GrammarType.TYPE2_CONTEXTFREE;

        var startSymbolAppearsOnRightSide = this.productions.stream()
                .allMatch(p -> p.right().contains(this.startSymbol));

        // Check for context sensitive grammars
        if (this.productions.stream().allMatch(production ->
                production.left().size() == 1 && production.left().getFirst().equals(this.startSymbol)
                        && !startSymbolAppearsOnRightSide && production.right().isEmpty()
                        || IntStream.range(0, production.left().size()).anyMatch(i -> {
                    if (!(production.left().get(i) instanceof Symbol.NonTerminal)) return false;

                    var pre = production.left().subList(0, i);
                    var post = production.left().subList(i + 1, production.left().size());

                    for (var j = 0; j < pre.size(); j++) {
                        if (j >= production.right().size() || !pre.get(j).equals(production.right().get(j))) {
                            return false;
                        }
                    }

                    for (var j = 0; j < post.size(); j++) {
                        var corresponding = production.right().size() - post.size() + j;
                        if (corresponding < 0 || !post.get(j).equals(production.right().get(corresponding))) {
                            return false;
                        }
                    }

                    return true;
                })
        )) return GrammarType.TYPE1_CONTEXTSENSITIVE;

        /* Check for monotone grammars. Monotone grammars are exactly as powerful as context-sensitive grammars,
            but with a much simpler definition.
         */
        if (this.productions.stream().allMatch(production -> production.left().size() == 1
                && production.left().getFirst().equals(this.startSymbol)
                && !startSymbolAppearsOnRightSide
                && production.right().isEmpty()
                || production.right().size() >= production.left().size()
        )) return GrammarType.TYPE1_MONOTONE;

        return GrammarType.TYPE0_FREE;
    }

    @Override
    public String toString() {
        var sb = new StringBuilder();

        if (this.startSymbol != null) {
            sb.append(String.format("start with %s\n", this.startSymbol.getRepresentation()));
        }

        for (var p : productions) {
            sb.append(String.format("%s -> %s%n",
                    p.left().stream().map(Symbol::getRepresentation).collect(Collectors.joining(" ")),
                    p.right().isEmpty() ? "ε" : p.right().stream().map(Symbol::getRepresentation).collect(Collectors.joining(" "))
            ));
        }

        return sb.toString();
    }
}


