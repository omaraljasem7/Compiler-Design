package de.thm.asc.generators.scanning.regex.parsing;

class Lexer {

    protected enum TokenType {
        L_PAREN,
        R_PAREN,
        L_BRACK,
        R_BRACK,
        PLUS,
        MINUS,
        ASTERISK,
        PIPE,
        DOT,
        QUESTION_MARK,
        LITERAL,
        EOF,
        ILLEGAL
    }

    protected record Token(TokenType type, String literal) {

        @Override
        public String toString() {
            return String.format("(Token %s %s)", type, literal);
        }
    }

    private static final char EOF = '\0';
    private final String code;
    private int position = 0;
    private char currentChar;

    protected Lexer(String code) {
        this.code = code;
    }

    private boolean isPrintableAscii(char c) {
        return c >= 0x20 && c <= 0x7e;
    }

    private char readChar() {
        if (position < code.length()) {
            return code.charAt(position);
        } else {
            return EOF;
        }
    }

    private void nextChar() {
        currentChar = readChar();
        position++;
    }

    protected void printTokens() {
        while (true) {
            var token = nextToken();
            System.out.println(token);
            if (token.type() == TokenType.EOF) {
                break;
            }
        }
    }

    protected Token nextToken() {
        nextChar();

        return switch (currentChar) {
            case '(' -> new Token(TokenType.L_PAREN, "(");
            case ')' -> new Token(TokenType.R_PAREN, ")");
            case '[' -> new Token(TokenType.L_BRACK, "[");
            case ']' -> new Token(TokenType.R_BRACK, "]");
            case '*' -> new Token(TokenType.ASTERISK, "*");
            case '|' -> new Token(TokenType.PIPE, "|");
            case '+' -> new Token(TokenType.PLUS, "+");
            case '-' -> new Token(TokenType.MINUS, "-");
            case '.' -> new Token(TokenType.DOT, ".");
            case '?' -> new Token(TokenType.QUESTION_MARK, "?");
            case '\\' -> {
                nextChar();

                switch (currentChar) {
                    case 'r':
                        yield new Token(TokenType.LITERAL, "\r");
                    case 't':
                        yield new Token(TokenType.LITERAL, "\t");
                    case 'n':
                        yield new Token(TokenType.LITERAL, "\n");
                    default:
                        yield new Token(TokenType.LITERAL, String.valueOf(currentChar));
                }
            }
            case EOF -> new Token(TokenType.EOF, String.valueOf(EOF));
            default -> {
                if (isPrintableAscii(currentChar)) {
                    yield new Token(TokenType.LITERAL, String.valueOf(currentChar));
                }

                yield new Token(TokenType.ILLEGAL, String.valueOf(currentChar));
            }
        };
    }
}
