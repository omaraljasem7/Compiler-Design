package de.thm.asc.generators.scanning.regex.ast;

/**
 * Empty nodes describe empty regular expressions, like the right operand in `a|` or the contents of `()`.
 */
public final class EmptyNode extends RegularExpression {

    @Override
    protected int getPrecedence() {
        return Integer.MAX_VALUE;
    }

    @Override
    public String toString() {
        return "()";
    }
}
