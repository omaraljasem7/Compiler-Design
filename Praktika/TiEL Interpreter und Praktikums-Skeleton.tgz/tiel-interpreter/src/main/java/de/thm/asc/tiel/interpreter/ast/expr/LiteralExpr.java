package de.thm.asc.tiel.interpreter.ast.expr;

import de.thm.asc.tiel.interpreter.backend.common.TiELValue;

public final class LiteralExpr extends Expr {

    public final TiELValue value;

    public LiteralExpr(TiELValue value) {
        this.value = value;
    }

    @Override
    public <R> R accept(ExprVisitor<R> visitor) {
        return visitor.visitLiteralExpr(this);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (!(obj instanceof LiteralExpr o)) return false;

        return value.equals(o.value);
    }
}
