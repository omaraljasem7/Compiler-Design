package de.thm.asc.generators.scanning.regex;

import de.thm.asc.generators.scanning.automata.*;
import de.thm.asc.generators.scanning.regex.ast.*;

/**
 * Thompson's construction (also called McNaughton-Yamada-Thompson algorithm) is an algorithm to translate a regular expression into a nondeterministic finite automaton (nfa).
 */
public class ThompsonsConstruction {

    protected final FiniteAutomatonBuilder builder = new FiniteAutomatonBuilder();

    protected ThompsonsConstruction() {

    }

    protected record PartialAutomaton(State entry, State exit) {

    }

    protected PartialAutomaton generate(RegularExpression regularExpression) {
        switch (regularExpression) {
            case ConcatenationNode conjunctionNode -> {
                var in = builder.newState();

                var out = builder.newState();

                var left = generate(conjunctionNode.left);
                var right = generate(conjunctionNode.right);

                builder.addTransition(Transition.newEpsilonTransition(left.exit, right.entry));
                builder.addTransition(Transition.newEpsilonTransition(in, left.entry));
                builder.addTransition(Transition.newEpsilonTransition(right.exit, out));

                return new PartialAutomaton(in, out);
            }
            case AlternationNode disjunctionNode -> {
                var left = generate(disjunctionNode.left);
                var right = generate(disjunctionNode.right);

                var entry = builder.newState();
                var exit = builder.newState();

                builder.addTransition(Transition.newEpsilonTransition(entry, left.entry));
                builder.addTransition(Transition.newEpsilonTransition(entry, right.entry));
                builder.addTransition(Transition.newEpsilonTransition(left.exit, exit));
                builder.addTransition(Transition.newEpsilonTransition(right.exit, exit));

                return new PartialAutomaton(entry, exit);
            }
            case LiteralNode literalNode -> {
                var entry = builder.newState();
                var exit = builder.newState();

                builder.addTransition(Transition.newSymbolTransition(entry, exit, new Symbol(literalNode.value)));

                return new PartialAutomaton(entry, exit);
            }
            case RepetitionNode repetitionNode -> {
                var in = builder.newState();
                var entry = builder.newState();

                var inner = generate(repetitionNode.value);

                var exit = builder.newState();
                var out = builder.newState();

                builder.addTransition(Transition.newEpsilonTransition(in, entry));
                if (repetitionNode.optional) builder.addTransition(Transition.newEpsilonTransition(entry, exit));
                builder.addTransition(Transition.newEpsilonTransition(exit, entry));
                builder.addTransition(Transition.newEpsilonTransition(exit, out));
                builder.addTransition(Transition.newEpsilonTransition(entry, inner.entry));
                builder.addTransition(Transition.newEpsilonTransition(inner.exit, exit));

                return new PartialAutomaton(in, out);
            }
            case EmptyNode ignored -> {
                var entry = builder.newState();
                var exit = builder.newState();

                builder.addTransition(Transition.newEpsilonTransition(entry, exit));

                return new PartialAutomaton(entry, exit);
            }
            case CharacterClassNode characterClassNode -> {
                var entry = builder.newState();
                var exit = builder.newState();

                for (var range : characterClassNode.ranges) {
                    for (var i = range.lower(); i <= range.upper(); i++) {
                        builder.addTransition(Transition.newSymbolTransition(entry, exit, new Symbol(i)));
                    }
                }

                return new PartialAutomaton(entry, exit);
            }
        }
    }

    /**
     * Constructs an automaton from a regex using Thompson's construction.
     *
     * @param regularExpression The regex node to generate the automaton from.
     * @return The generated automaton.
     */
    public static FiniteAutomaton construct(RegularExpression regularExpression) {
        var instance = new ThompsonsConstruction();

        var full = instance.generate(regularExpression);

        instance.builder.setInitialState(full.entry);
        instance.builder.makeFinalState(full.exit);

        return instance.builder.result();
    }
}
