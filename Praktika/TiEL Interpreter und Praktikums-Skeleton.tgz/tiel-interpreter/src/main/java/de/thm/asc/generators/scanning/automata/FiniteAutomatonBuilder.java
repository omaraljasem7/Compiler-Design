package de.thm.asc.generators.scanning.automata;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Allow the successive construction of an automaton.
 */
public class FiniteAutomatonBuilder {

    private State initialState = null;
    private final Set<State> states = new HashSet<>();
    private final Set<Transition> transitions = new HashSet<>();
    private final Set<State> finalStates = new HashSet<>();
    private int stateCounter = 0;

    /**
     * Adds a new state to the automaton. The name is constructed from the given prefix and an internal counter.
     *
     * @param prefix The prefix to be used for the state's name.
     * @return The newly added state.
     */
    public State newState(String prefix) {
        while (true) {
            var candidate = new State(prefix + stateCounter);

            if (!states.contains(candidate)) {
                states.add(candidate);
                return candidate;
            }

            stateCounter++;
        }
    }

    /**
     * Adds a new state to the automaton using 's' as the prefix.
     *
     * @return The newly added state.
     */
    public State newState() {
        return newState("q");
    }

    /**
     * Sets the initial state of this automaton to the given state.
     *
     * @param initialState The state to be set as the initial state.
     */
    public void setInitialState(State initialState) {
        this.initialState = initialState;
    }

    /**
     * Adds the given state to the set of final states of this automaton.
     *
     * @param state The state to be added to the final states.
     */
    public void makeFinalState(State state) {
        this.finalStates.add(state);
    }

    /**
     * Adds a new transition to the automaton. Use the static constructor functions in the {@link Transition} class
     *
     * @param transition The transition to add to this automaton.
     */
    public void addTransition(Transition transition) {
        transitions.add(transition);
    }

    /**
     * Finalizes the built automaton into an instance of the immutable {@link FiniteAutomaton} class.
     *
     * @return The built automaton.
     */
    public FiniteAutomaton result() {
        return new FiniteAutomaton(
                new HashSet<>(states),
                transitions.stream().flatMap(t -> t.symbol.stream()).collect(Collectors.toSet()),
                initialState,
                new HashSet<>(finalStates),
                new HashSet<>(transitions)
        );
    }
}
