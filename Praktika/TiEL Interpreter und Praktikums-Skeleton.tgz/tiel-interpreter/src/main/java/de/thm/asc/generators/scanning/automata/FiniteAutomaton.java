package de.thm.asc.generators.scanning.automata;

import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Represents the 5-tuple of an automaton as described in the lecture.
 *
 * @param states       The set containing all states of the automaton.
 * @param alphabet     The set containing the alphabet of the automaton.
 * @param initialState The initial state of the automaton.
 * @param finalStates  The set containing all final states of the automaton.
 * @param transitions  The set containing all transitions of the automaton,
 */
public record FiniteAutomaton(
        Set<State> states,
        Set<Symbol> alphabet,
        State initialState,
        Set<State> finalStates,
        Set<Transition> transitions
) {
    /**
     * Determines whether this automaton meets all required conditions to be considered deterministic.
     *
     * @return Whether this automaton is deterministic.
     */
    public boolean isDeterministic() {
        // If there is any epsilon transition, the automaton is nondeterministic
        if (transitions.stream().anyMatch(Transition::isEpsilonTransition)) return false;

        for (var state : states) {
            // Group transitions for this state by their symbol
            var grouped = transitions.stream()
                    .filter(t -> t.left.equals(state))
                    .collect(Collectors.groupingBy(Transition::symbol));

            // If there is any symbol that has more than 1 transition from this state, the automaton is nondeterministic
            if (grouped.entrySet().stream().anyMatch(e -> e.getValue().size() > 1))
                return false;
        }

        // If neither of the previous checks finds nondeterminism, the automaton is deterministic
        return true;
    }

    /**
     * Converts this automaton to a deterministic automaton.
     *
     * @return The converted deterministic automaton.
     */
    public FiniteAutomaton toDFA() {
        if (isDeterministic()) return this;

        return PowersetConstruction.apply(this);
    }

    @Override
    public String toString() {
        return toDotCode();
    }

    /**
     * Converts this automaton to GraphViz dot code.
     *
     * @return The generated dot code.
     */
    public String toDotCode() {
        class Util {
            static String escape(String s) {
                return s
                        .replace("\\", "\\\\")
                        .replace("\r", "\\\\r")
                        .replace("\t", "\\\\t")
                        .replace(" ", "0x20")
                        .replace("\n", "\\\\n")
                        .replace("\"", "\\\"")
                        .chars()
                        .mapToObj(c -> (char) c)
                        .map(c -> {
                            Character.UnicodeBlock block = Character.UnicodeBlock.of(c);
                            var printable = (!Character.isISOControl(c)) &&
                                    c != KeyEvent.CHAR_UNDEFINED &&
                                    block != null &&
                                    block != Character.UnicodeBlock.SPECIALS;

                            return printable ? c.toString() : "0x" + Integer.toString(c, 16);

                        })
                        .collect(Collectors.joining());
            }
        }

        var sb = new StringBuilder();

        sb.append("digraph automata {\n");
        sb.append("    node [shape=doublecircle]; ");
        sb.append(finalStates.stream().map(State::name).collect(Collectors.joining("; ")));
        sb.append(";\n");
        sb.append("    node [shape=point, style=invis]; ENTRY;\n");
        sb.append("    node [shape=circle, style=solid];\n");
        sb.append(String.format("    ENTRY -> %s;\n", initialState.name()));

        record StatePair(State left, State right) {}

        var grouped = transitions.stream().filter(t -> !t.isEpsilonTransition()).collect(Collectors.groupingBy(t -> new StatePair(t.left, t.right)));

        grouped.forEach((k, v) -> {
            var sortedCharacters = v.stream().map(t -> t.symbol().value()).sorted().toList();
            var i = 0;
            var label = new StringBuilder();

            while (i < sortedCharacters.size()) {
                var j = i + 1;

                label.append(sortedCharacters.get(i));

                while (j < sortedCharacters.size() && sortedCharacters.get(j) == sortedCharacters.get(i) + (j - i)) j++;

                if (j > i + 1) {
                    label.append(j == i + 2 ? "," : "-");
                    label.append(sortedCharacters.get(j - 1));
                }

                i = j;

                if (i < sortedCharacters.size()) label.append(",");
            }

            sb.append(String.format("    \"%s\" -> \"%s\" [label=\"%s\"]\n", k.left.name(), k.right.name(), Util.escape(label.toString())));
        });

        for (var t : transitions) {
            if (!t.isEpsilonTransition()) continue;

            sb.append(String.format("    \"%s\" -> \"%s\" [label=\"%s\"]\n", t.left.name(), t.right.name(), Util.escape(t.symbolString())));
        }

        sb.append("}\n");

        return sb.toString();
    }
}
