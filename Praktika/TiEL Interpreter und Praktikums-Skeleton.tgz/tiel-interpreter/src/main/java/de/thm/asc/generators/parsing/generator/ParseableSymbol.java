package de.thm.asc.generators.parsing.generator;

import de.thm.asc.generators.parsing.grammar.Symbol;

public interface ParseableSymbol {

    Symbol getUnderlyingSymbol();
}
