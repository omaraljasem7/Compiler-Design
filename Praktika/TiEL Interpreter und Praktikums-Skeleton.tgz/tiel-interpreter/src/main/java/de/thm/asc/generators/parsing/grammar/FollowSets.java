package de.thm.asc.generators.parsing.grammar;

import de.thm.asc.tiel.interpreter.util.MarkdownTable;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * Represents the follow sets for a context free grammar.
 * Note: Only context-free grammars are supported!
 */
public class FollowSets {

    private final Grammar grammar;
    private final Map<Symbol.NonTerminal, Set<FollowElement>> followSets = new HashMap<>();

    public FollowSets(Grammar grammar) {
        this.grammar = grammar;

        if (!this.grammar.type.get().isSubSetOf(GrammarType.TYPE2_CONTEXTFREE)) throw new UnsupportedOperationException("Cannot calculate follow sets for non context-free grammar.");

        this.calculate();
    }

    /**
     * Generates a Markdown table from this instance.
     *
     * @return The Markdown table.
     */
    public MarkdownTable toMarkdownTable() {
        var table = new MarkdownTable()
                .setHeader(new MarkdownTable.Row()
                        .addCell("Non-Terminal").addCell("Follow Set"));

        for (var e : followSets.entrySet()) {
            table.addRow(new MarkdownTable.Row()
                    .addCell(String.valueOf(e.getKey().value()))
                    .addCell(e.getValue().stream()
                            .map(s -> String.valueOf(s.isDollar() ? "$" : s.symbol().value()))
                            .collect(Collectors.joining(", "))));
        }

        return table;
    }

    /**
     * Populates the internal cache {@link FollowSets#followSets} of follow sets for the entire grammar.
     */
    private void calculate() {
        // TODO (Aufgabe 2): Implement the calculation of the follow sets by populating the followSets map in this class.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public Set<FollowElement> get(Symbol.NonTerminal nonTerminal) {
        return this.followSets.get(nonTerminal);
    }

    /**
     * Finds all symbol substrings that follow the given target symbol in the given symbol string.
     * Example: findAllPostfixes(aBcdBe, B) -> [[cdBe], [e]]
     * Example: findAllPostfixes(aB, B) -> [[]]
     * Example: findAllPostfixes(Ba, B) -> [[a]]
     *
     * @param list   The list to find the postfixes in. Usually the right hand side of a production.
     * @param target The target element to search for.
     * @return A list containing all found postfix lists.
     */
    private static List<List<Symbol>> findAllPostfixes(List<Symbol> list, Symbol.NonTerminal target) {
        return IntStream.range(0, list.size()) // Get all indices for the list
                .filter(i -> list.get(i).equals(target)) // Find indices of all occurences of the target symbol
                .mapToObj(i -> list.subList(i + 1, list.size())) // Get the rest for the list after the found target indices.
                .collect(Collectors.toList());
    }

    /**
     * Represents an element in a follow set. Either a terminal symbol or the end-of-input symbol $.
     *
     * @param _symbol The optional symbol. Do not use this constructor directly. Use the static method {@link FollowElement#of(Symbol.Terminal)} instead.
     */
    public record FollowElement(Optional<Symbol.Terminal> _symbol) {
        public Symbol.Terminal symbol() {
            if (this._symbol.isEmpty()) {
                throw new RuntimeException("symbol() called on an end of file ($) follow set element.");
            }

            return this._symbol.get();
        }

        /**
         * @return Whether this element is the end-of-input element $.
         */
        public boolean isDollar() {
            return this._symbol.isEmpty();
        }

        /**
         * The end-of-input marker $.
         */
        public static final FollowElement DOLLAR = new FollowElement(Optional.empty());

        /**
         * @param terminal A terminal symbol.
         * @return A follow element for this terminal.
         */
        public static FollowElement of(Symbol.Terminal terminal) {
            return new FollowElement(Optional.of(terminal));
        }

        @Override
        public String toString() {
            return this.isDollar() ? "<$>" : this.symbol().getRepresentation();
        }
    }
}

