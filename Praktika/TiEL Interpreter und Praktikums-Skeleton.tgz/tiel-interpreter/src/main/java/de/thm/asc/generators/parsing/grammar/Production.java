package de.thm.asc.generators.parsing.grammar;

import java.util.List;

/**
 * A production of the form 'from -> to'.
 *
 * @param left  The left side of the production.
 * @param right The right side of the production.
 */
public record Production(List<Symbol> left, List<Symbol> right) {

    /**
     * @return The single nonterminal on the left hand side.
     * @throws IllegalArgumentException if this production is not a context free production.
     */
    public Symbol.NonTerminal getLeftNonterminal() {
        if (left.size() != 1 || !(left.getFirst() instanceof Symbol.NonTerminal))
            throw new IllegalArgumentException("Cannot get left nonterminal for a production that is not context free.");

        return ((Symbol.NonTerminal) left.getFirst());
    }

    public boolean isEpsilonProduction() {
        return this.right.isEmpty();
    }
}


