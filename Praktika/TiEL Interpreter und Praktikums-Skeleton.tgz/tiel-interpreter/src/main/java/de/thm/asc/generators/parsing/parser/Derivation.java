package de.thm.asc.generators.parsing.parser;

import de.thm.asc.generators.parsing.grammar.Symbol;

import java.util.List;
import java.util.stream.Collectors;

/**
 * A derivation is a sequence of symbol strings that describes the derivation process to derive a word from the start symbol of a grammar.
 * @param steps
 */
public record Derivation(List<List<Symbol>> steps) {

    @Override
    public String toString() {
        return steps.stream()
                .map(state -> state.stream()
                        .map(Symbol::getRepresentation)
                        .collect(Collectors.joining("")))
                .collect(Collectors.joining("\n=> "));
    }
}


