package de.thm.asc.generators.scanning.regex.ast;

/**
 * Repetition nodes describe optional or non-optional repetition such as `a*` and `a+`.
 */
public final class RepetitionNode extends RegularExpression {

    public final RegularExpression value;
    public final boolean optional;

    public RepetitionNode(RegularExpression value, boolean optional) {
        this.value = value;
        this.optional = optional;
    }

    @Override
    protected int getPrecedence() {
        return 4;
    }

    @Override
    public String toString() {
        if (optional) {
            return String.format("%s*", formatByPrecedence(value));
        }

        return String.format("%s+", formatByPrecedence(value));
    }
}
