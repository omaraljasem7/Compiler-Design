package de.thm.asc.generators.scanning.generator;

import de.thm.asc.generators.scanning.automata.PowersetConstruction;

public class PowersetConstructionWithSemanticActions extends PowersetConstruction {

    private PowersetConstructionWithSemanticActions(FiniteAutomatonWithSemanticActions automaton) {
        super(automaton.automaton());
    }

    public static FiniteAutomatonWithSemanticActions generate(FiniteAutomatonWithSemanticActions automaton) {
        var instance = new PowersetConstructionWithSemanticActions(automaton);

        var result = instance.constructWithStateMap();

        var transformedSemantics = result.resultAutomaton().finalStates().stream().map(state -> {
            var originalStates = result.originalStateMap().get(state);

            return new FiniteAutomatonWithSemanticActions.SemanticFinalState(state, automaton.semanticFinalStates().stream()
                    .filter(sfs -> originalStates.contains(sfs.state()))
                    .findFirst().get().action());
        }).toList();

        return new FiniteAutomatonWithSemanticActions(result.resultAutomaton(), transformedSemantics);
    }
}
