package de.thm.asc.tiel.interpreter.scanning;

import de.thm.asc.generators.scanning.generator.ScannerSpecification;
import de.thm.asc.tiel.interpreter.util.LazyValue;

import static de.thm.asc.tiel.interpreter.scanning.TokenType.*;

public class TiELScannerGenerated {

    public static ScannerSpecification specification() {
        var scanner = new ScannerSpecification.Builder();

        scanner.ignore("[ \\r\\t\\n]+");
        scanner.ignore("//(.)*");

        scanner.rule("\\(", LEFT_PAREN);
        scanner.rule("\\)", RIGHT_PAREN);
        scanner.rule("{", LEFT_BRACE);
        scanner.rule("}", RIGHT_BRACE);
        scanner.rule(";", SEMICOLON);
        scanner.rule(",", COMMA);
        scanner.rule("\\-", MINUS);
        scanner.rule("\\*", STAR);
        scanner.rule("\\+", PLUS);
        scanner.rule("/", SLASH);
        scanner.rule("=", EQUAL);
        scanner.rule("==", EQUAL_EQUAL);
        scanner.rule("<", LESS);
        scanner.rule("<=", LESS_EQUAL);
        scanner.rule(">", GREATER);
        scanner.rule(">=", GREATER_EQUAL);
        scanner.rule("!", NOT);
        scanner.rule("!=", NOT_EQUAL);
        scanner.rule("and", AND);
        scanner.rule("false", FALSE);
        scanner.rule("fun", FUN);
        scanner.rule("if", IF);
        scanner.rule("else", ELSE);
        scanner.rule("elif", ELIF);
        scanner.rule("nil", NIL);
        scanner.rule("or", OR);
        scanner.rule("return", RETURN);
        scanner.rule("true", TRUE);
        scanner.rule("var", VAR);
        scanner.rule("while", WHILE);
        scanner.rule("not", NOT);
        scanner.rule("\"([\u0020-\u0021\u0023-\u007e])*\"", STRING, lexeme -> lexeme.substring(1, lexeme.length() - 1));
        scanner.rule("[a-zA-Z_]([a-zA-Z_0-9])*", IDENTIFIER, lexeme -> lexeme);
        scanner.rule("[0-9]+((\\.[0-9]+))?", NUMBER, Double::parseDouble);
        scanner.rule("0x[0-9a-fA-F]+", NUMBER, lexeme -> Integer.parseInt(lexeme.substring(2), 16));

        return scanner.getSpecification();
    }

    public static LazyValue<TiELScanner> SCANNER = new LazyValue<>(() -> specification().generate().asScanner());
}
