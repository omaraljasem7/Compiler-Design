package de.thm.asc.tiel.interpreter.ast.expr;

public final class AssignExpr extends Expr {

    public final String name;
    public final Expr value;

    public AssignExpr(String name, Expr value) {
        this.name = name;
        this.value = value;
    }

    @Override
    public <R> R accept(ExprVisitor<R> visitor) {
        return visitor.visitAssignExpr(this);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) return true;
        if (!(obj instanceof AssignExpr o)) return false;

        return name.equals(o.name) && value.equals(o.value);
    }
}
