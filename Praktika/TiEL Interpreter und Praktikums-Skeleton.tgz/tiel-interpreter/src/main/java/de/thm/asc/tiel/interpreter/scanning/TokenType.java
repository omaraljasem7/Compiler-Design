package de.thm.asc.tiel.interpreter.scanning;

import de.thm.asc.generators.parsing.generator.ParseableSymbol;
import de.thm.asc.generators.parsing.grammar.Symbol;
import de.thm.asc.generators.scanning.generator.ScannableTokenType;

/**
 * The TokenType enum defines the various types of tokens
 * that can be recognized in the source code during lexical analysis.
 */
//<< 03-scan, token-types, Aufzählungswerte Grundsymbole
public enum TokenType implements ScannableTokenType, ParseableSymbol {
    IDENTIFIER,     // Variable or function name

    // Special symbols
    LEFT_PAREN,     // (
    RIGHT_PAREN,    // )
    LEFT_BRACE,     // {
    RIGHT_BRACE,    // }
    COMMA,          // ,
    MINUS,          // -
    //>>
    PLUS,           // +
    STAR,           // *
    SLASH,          // /
    SEMICOLON,      // ;
    EQUAL,          // =
    EQUAL_EQUAL,    // ==
    NOT_EQUAL,      // !=
    LESS,           // <
    LESS_EQUAL,     // <=
    GREATER,        // >
    GREATER_EQUAL,  // >=


    // Keywords
    FUN,        // Function definition keyword
    VAR,        // Variable declaration keyword
    IF,         // Conditional statement keyword
    ELSE,       // Begins an else block in conditional statements
    ELIF,       // Begins an else-if block in conditional statements
    WHILE,      // Loop keyword
    RETURN,     // Return statement keyword
    AND,        // Logical AND operator
    OR,         // Logical OR operator
    NOT,        // Logical NOT operator
    TRUE,       // Boolean literal 'true'
    FALSE,      // Boolean literal 'false'
    NIL,        // Null-like literal keyword

    // Literals
    NUMBER,         // Numeric literal
    STRING,         // String literal

    // End of file marker
    EOF            // Signals the end of the source input
    ;

    @Override
    public Symbol getUnderlyingSymbol() {
        return new Symbol.Terminal(this);
    }
}

