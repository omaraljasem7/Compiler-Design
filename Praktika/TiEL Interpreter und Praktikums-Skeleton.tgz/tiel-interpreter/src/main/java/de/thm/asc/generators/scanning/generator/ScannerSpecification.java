package de.thm.asc.generators.scanning.generator;

import de.thm.asc.generators.scanning.regex.ast.RegularExpression;
import de.thm.asc.generators.scanning.regex.parsing.RegexParser;

import java.util.ArrayList;
import java.util.function.Function;
import java.util.List;

public record ScannerSpecification(List<Rule> rules) {

    public record Rule(RegularExpression regex, ScannableTokenType type, Function<String, Object> transformer) {}

    public FiniteAutomatonWithSemanticActions generate() {
        return PowersetConstructionWithSemanticActions.generate(ScannerThompsonsConstruction.construct(this));
    }

    public static class Builder {

        private final List<Rule> rules = new ArrayList<>();

        public final ScannerSpecification getSpecification() {
            return new ScannerSpecification(List.copyOf(rules));
        }

        public final void ignore(String regex) {
            rule(regex, null, null);
        }

        public final void rule(String regex, ScannableTokenType type) {
            rule(regex, type, null);
        }

        public final void rule(String regex, ScannableTokenType type, Function<String, Object> transformer) {
            var ast = RegexParser.parse(regex);

            rules.add(new Rule(ast, type, transformer));
        }
    }
}
