package de.thm.asc.tiel.interpreter.parsing;

import de.thm.asc.generators.parsing.generator.ParserSpecification;
import de.thm.asc.generators.parsing.parser.ll1.LL1Automaton;
import de.thm.asc.tiel.interpreter.ast.expr.*;
import de.thm.asc.tiel.interpreter.ast.stmt.*;
import de.thm.asc.tiel.interpreter.backend.common.TiELValue;
import de.thm.asc.tiel.interpreter.error.ParsingError;
import de.thm.asc.tiel.interpreter.scanning.Token;
import de.thm.asc.tiel.interpreter.scanning.TokenType;
import de.thm.asc.tiel.interpreter.util.LazyValue;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import static de.thm.asc.tiel.interpreter.scanning.TokenType.*;

public class TiELParserGenerated {

    interface UnfinishedExpression extends Function<Expr, Expr> {
        static UnfinishedExpression identity() {
            return e -> e;
        }

        static UnfinishedExpression of(Function<Expr, Expr> f) {
            return f::apply;
        }

        static UnfinishedExpression chain(Function<Expr, Expr> cons, UnfinishedExpression tail) {
            return UnfinishedExpression.of(l -> tail.apply(cons.apply(l)));
        }
    }

    private static <T> List<T> cons(T head, List<T> tail) {
        var list = new ArrayList<T>();
        list.add(head);
        list.addAll(tail);
        return list;
    }

    static ParserSpecification specification() {
        var parser = new ParserSpecification.Builder(TokenType.class);

        // ---------- Non-terminals ----------
        var statementList = parser.nonTerminal("statementList");

        var start = parser.nonTerminal("start");

        // ---------- Start symbol ---------- 
        parser.startSymbol(start);

        start.produces(statementList, EOF).withSemantic($ -> $.get(0));

        // TODO (Aufgabe 2): Implement the rest of the TiEL grammar in LL1 form. See ParserExample.java for an example.

        return parser.getSpecification();
    }

    public static class LL1TiELParser implements TiELParser {
        public final ParserSpecification specification;
        public final LL1Automaton automaton;

        LL1TiELParser(ParserSpecification specification) {
            this.specification = specification;
            this.automaton = specification.getParser();
        }

        @Override
        public List<Stmt> parse(List<Token> tokens) {
            var parseResult = automaton.parse(tokens);

            if (parseResult.derivationTree().isEmpty()) {
                throw ((LL1Automaton.StateRecording.ErrorAction) parseResult.recording().getStates().getLast().action()).error();
            }

            return parseResult.derivationTree()
                    .map(tree -> ((List<Stmt>) specification.generateAst(tree.getRoot())))
                    .orElse(null);
        }
    }

    public static LazyValue<LL1TiELParser> PARSER = new LazyValue<>(() -> new LL1TiELParser(specification()));
}
