package de.thm.asc.tiel.interpreter.backend.common;

import de.thm.asc.tiel.interpreter.scanning.Token;

import java.util.List;

/**
 * Represents a callable entity in the TiEL programming language.
 * Classes implementing this interface can be invoked as functions.
 */
non-sealed public interface TiELCallable extends TiELValue {

    /**
     * Returns the number of parameters required by the callable entity.
     *
     * @return The number of parameters (arity) expected by the callable.
     */
    int arity();

    /**
     * Executes the callable entity with the given arguments.
     *
     * @param arguments The list of arguments provided to the callable entity.
     * @param errorPosition The position at which a potential error will be thrown.
     * @return The result of the function execution.
     */
    TiELValue call(List<TiELValue> arguments, Token.Position errorPosition);
}
