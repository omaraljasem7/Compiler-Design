package de.thm.asc.generators.scanning.regex.ast;

/**
 * Concatenation nodes describe concatenation in Regex such as `ab`.
 */
public final class ConcatenationNode extends RegularExpression {

    public final RegularExpression left;
    public final RegularExpression right;

    public ConcatenationNode(RegularExpression left, RegularExpression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    protected int getPrecedence() {
        return 3;
    }

    @Override
    public String toString() {
        return formatByPrecedence(left) + formatByPrecedence(right);
    }
}
