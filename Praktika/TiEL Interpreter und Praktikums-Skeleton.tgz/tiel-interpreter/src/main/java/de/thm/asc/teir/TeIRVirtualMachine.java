package de.thm.asc.teir;

import de.thm.asc.tiel.interpreter.backend.common.Common;
import de.thm.asc.tiel.interpreter.backend.common.Environment;
import de.thm.asc.tiel.interpreter.backend.common.TiELCallable;
import de.thm.asc.tiel.interpreter.backend.common.TiELValue;
import de.thm.asc.tiel.interpreter.error.RuntimeError;
import de.thm.asc.tiel.interpreter.backend.evaluation.*;
import de.thm.asc.tiel.interpreter.scanning.Token;

import java.util.*;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class TeIRVirtualMachine {

    public static class ExecutionState {
        Environment scope;
        int pc;

        ExecutionState(Environment scope, int pc) {
            this.scope = scope;
            this.pc = pc;
        }
    }

    private final List<StackInstruction> instructions;
    private final Map<String, Integer> labels;

    private final Stack<TiELValue> stack = new Stack<>();
    private final Stack<ExecutionState> callStack = new Stack<>();
    ExecutionState state;

    public TeIRVirtualMachine(Environment environment, List<StackInstruction> instructions) {
        this.instructions = instructions;

        labels = IntStream.range(0, instructions.size())
                .filter(i -> instructions.get(i) instanceof StackInstruction.Label)
                .boxed()
                .collect(Collectors.toMap(i -> ((StackInstruction.Label) instructions.get(i)).name(), i -> i));

        state = new ExecutionState(environment, 0);
    }

    static double num(TiELValue value) {
        if (!(value instanceof TiELValue.TNumber(double value1))) throw new RuntimeError("Not a number", Token.Position.ZERO);

        return value1;
    }

    static private void binary(Stack<TiELValue> stack, BiFunction<TiELValue, TiELValue, TiELValue> function) {
        var rhs = stack.pop();
        var lhs = stack.pop();

        stack.push(function.apply(lhs, rhs));
    }

    public void run() {
        while (state.pc < instructions.size()) {
            var instruction = instructions.get(state.pc);

            switch (instruction) {
                case StackInstruction.Add ignored -> binary(stack, (l, r) -> Common.wrap(num(l) + num(r)));
                case StackInstruction.Sub ignored -> binary(stack, (l, r) -> Common.wrap(num(l) - num(r)));
                case StackInstruction.Mul ignored -> binary(stack, (l, r) -> Common.wrap(num(l) * num(r)));
                case StackInstruction.Div ignored -> binary(stack, (l, r) -> Common.wrap(num(l) / num(r)));
                case StackInstruction.EQ ignored -> binary(stack, (l, r) -> Common.wrap(l.equals(r)));
                case StackInstruction.NE ignored -> binary(stack, (l, r) -> Common.wrap(!l.equals(r)));
                case StackInstruction.GE ignored -> binary(stack, (l, r) -> Common.wrap(num(l) >= num(r)));
                case StackInstruction.GT ignored -> binary(stack, (l, r) -> Common.wrap(num(l) > num(r)));
                case StackInstruction.LE ignored -> binary(stack, (l, r) -> Common.wrap(num(l) <= num(r)));
                case StackInstruction.LT ignored -> binary(stack, (l, r) -> Common.wrap(num(l) < num(r)));

                case StackInstruction.Dup ignored -> stack.push(stack.peek());
                case StackInstruction.Pop ignored -> stack.pop();
                case StackInstruction.PushC pushC -> stack.push(pushC.value());

                case StackInstruction.OpenFrame ignored -> state.scope = new Environment(state.scope);
                case StackInstruction.CloseFrame ignored -> state.scope = state.scope.enclosing;
                case StackInstruction.PushVar pushVar -> stack.push(state.scope.get(pushVar.name(), Token.Position.ZERO));
                case StackInstruction.CreateVar createVar -> state.scope.define(createVar.name(), TiELValue.NIL, Token.Position.ZERO);
                case StackInstruction.SetVar setVar -> state.scope.assign(setVar.name(), stack.pop(), Token.Position.ZERO);

                case StackInstruction.Jmp jmp -> state.pc = labels.get(jmp.label());
                case StackInstruction.JmpIfTruthy jmpIfNotZero -> {
                    if (Common.isTruthy(stack.pop())) state.pc = labels.get(jmpIfNotZero.label());
                }
                case StackInstruction.JmpIfFalsy jmpIfNotZero -> {
                    if (!Common.isTruthy(stack.pop())) state.pc = labels.get(jmpIfNotZero.label());
                }
                case StackInstruction.Label ignored -> {} // Labels are instructions in this machine, but do nothing. This is unrealistic, but convenient.
                case StackInstruction.Call ignored -> {
                    switch (stack.pop()) {
                        case TiELValue.TeIRClosure f -> {
                            callStack.push(state);
                            state = new ExecutionState(f.environment(), labels.get(f.label()));
                        }
                        case TiELCallable tiELCallable -> {
                            var arguments = new ArrayList<TiELValue>();

                            for (var i = 0; i < tiELCallable.arity(); i++) {
                                arguments.add(stack.pop());
                            }

                            // Arguments are pushed from left to right, but popped from right to left. So we need to reverse the list.
                            var result = tiELCallable.call(arguments.reversed(), Token.Position.ZERO);

                            stack.push(result);
                        }
                        default -> throw new RuntimeError("Can only call functions.", Token.Position.ZERO);
                    }
                }
                case StackInstruction.Return ignored -> state = callStack.pop();// Data stack is shared for all functions, no need to handle the return value explicitly
                case StackInstruction.CreateClosure createClosure -> stack.push(new TiELValue.TeIRClosure(createClosure.label(), state.scope));
                case StackInstruction.TiELInterpretedExpressionFallback expr -> stack.push(new Evaluator(state.scope).evaluate(expr.expr()));
                case StackInstruction.TiELInterpretedStatementFallback stmt -> new Evaluator(state.scope).execute(stmt.stmt());
            }

            state.pc++;
        }
    }
}
