package de.thm.asc.tiel.interpreter.backend.evaluation;

import de.thm.asc.tiel.interpreter.ast.stmt.FunctionDeclStmt;
import de.thm.asc.tiel.interpreter.backend.common.Environment;
import de.thm.asc.tiel.interpreter.backend.common.TiELCallable;
import de.thm.asc.tiel.interpreter.backend.common.TiELValue;
import de.thm.asc.tiel.interpreter.scanning.Token;

import java.util.List;

/**
 * Represents a callable function in the TiEL programming language.
 * This class implements {@link TiELCallable} and wraps a function declaration
 * along with its closure environment.
 */
class TiELFunction implements TiELCallable {

    private final FunctionDeclStmt declaration;
    private final Environment environment;

    /**
     * Constructs a new TiELFunction instance.
     *
     * @param declaration The function declaration.
     * @param environment The environment that is closed over in which the function was declared.
     */
    TiELFunction(FunctionDeclStmt declaration, Environment environment) {
        this.declaration = declaration;
        this.environment = environment;
    }

    /**
     * Returns the number of parameters the function accepts.
     *
     * @return The arity of the function.
     */
    @Override
    public int arity() {
        return declaration.params.size();
    }

    /**
     * Calls the function with the given arguments.
     *
     * @param arguments     The arguments passed to the function.
     * @param errorPosition The position at which a potential error will be thrown.
     * @return The result of function execution, or {@code null} if no return value is specified.
     */
    @Override
    public TiELValue call(List<TiELValue> arguments, Token.Position errorPosition) {
        var environment = new Environment(this.environment);

        for (var i = 0; i < declaration.params.size(); i++) {
            environment.define(declaration.params.get(i), arguments.get(i), errorPosition);
        }

        try {
            new Evaluator(environment).interpret(declaration.body.statements);
        } catch (ReturnException returnValue) {
            return returnValue.value;
        }

        return TiELValue.NIL;
    }

    /**
     * Returns a string representation of the function.
     *
     * @return A string in the format "<fn functionName>".
     */
    @Override
    public java.lang.String toString() {
        return java.lang.String.format("<fn %s>", declaration.name);
    }
}
