package de.thm.asc.generators.scanning.regex.ast;

public sealed abstract class RegularExpression
        permits AlternationNode, ConcatenationNode, EmptyNode, LiteralNode, RepetitionNode, CharacterClassNode {

    /**
     * Returns the operator precedence of this node.
     * Based on <a href="https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap09.html#tag_09_04_08">IEEE Std 1003.1-2017</a>
     *
     * @return The node's precedence.
     */
    abstract protected int getPrecedence();

    protected String formatByPrecedence(RegularExpression operand) {
        if (getPrecedence() > operand.getPrecedence()) {
            return String.format("(%s)", operand);
        }

        return operand.toString();
    }

    @Override
    public abstract String toString();
}
