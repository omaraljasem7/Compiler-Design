package de.thm.asc.generators.scanning.regex.parsing;

import de.thm.asc.generators.scanning.regex.ast.RegularExpression;

public class RegexParser {

    /**
     * Parses a string containing a regex and returns the generated abstract syntax tree (AST).
     *
     * @param s The string to be parsed.
     * @return The AST of the regex.
     */
    public static RegularExpression parse(String s) {
        var lexer = new Lexer(s);
        var parser = new Parser(lexer);

        return parser.parse();
    }
}
