package de.thm.asc.tiel.interpreter.parsing;

import de.thm.asc.tiel.interpreter.scanning.TiELScannerHandwritten;
import de.thm.asc.tiel.util.ResourceUtil;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class TiELParserTest {

    static void compareCode(String source) {
        var handwrittenScannerTokens = TiELScannerHandwritten.getScanner().scan(source);

        var generatedParserStatements = TiELParserGenerated.PARSER.get().parse(handwrittenScannerTokens);
        var handwrittenParserStatements = TiELParserHandwritten.getParser().parse(handwrittenScannerTokens);

        assertEquals(generatedParserStatements, handwrittenParserStatements);
    }

    private static void compare(String test) {
        var source = ResourceUtil.getTestSourceCode(test);

        compareCode(source);
    }

    /**
     * Tests that the handwritten and LL1-based parser implementations behave identically. Must pass for assignment 2.
     */
    @TestFactory
    public List<DynamicTest> testParserEquivalence() throws IOException {
        return ResourceUtil.getTestFiles().stream().map(test -> dynamicTest(test, () -> compare(test))).toList();
    }
}