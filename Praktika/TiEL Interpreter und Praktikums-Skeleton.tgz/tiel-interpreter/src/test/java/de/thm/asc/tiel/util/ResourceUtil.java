package de.thm.asc.tiel.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ResourceUtil {

    private static String readResourceAsString(String resourceName) {

        try (var inputStream = ResourceUtil.class.getClassLoader().getResourceAsStream(resourceName)) {
            if (inputStream == null) {
                throw new IllegalArgumentException("Resource not found: " + resourceName);
            }
            try (var scanner = new Scanner(inputStream, StandardCharsets.UTF_8)) {
                scanner.useDelimiter("\\A");
                return scanner.hasNext() ? scanner.next() : "";
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading resource", e);
        }
    }

    public static String getTestSourceCode(String name) {
        return readResourceAsString("tests/" + name);
    }

    public static List<String> getTestFiles() throws IOException {
        List<String> filenames = new ArrayList<>();

        try (
                InputStream in = ResourceUtil.class.getClassLoader().getResourceAsStream("tests/");
                BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            String resource;

            while ((resource = br.readLine()) != null) {
                filenames.add(resource);
            }
        }

        return filenames;
    }
}
