package de.thm.asc.tiel.interpreter.scanning;

import de.thm.asc.tiel.util.ResourceUtil;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class TiELScannerTest {

    private void compare(String test) {
        var source = ResourceUtil.getTestSourceCode(test);

        var generated = TiELScannerGenerated.SCANNER.get().scan(source);
        var handwritten = TiELScannerHandwritten.getScanner().scan(source);

        assertEquals(generated, handwritten);
    }

    /**
     * Tests that the handwritten and automaton-based scanner implementations behave identically. Must pass for assignment 1.
     */
    @TestFactory
    public List<DynamicTest> testParserEquivalence() throws IOException {
        return ResourceUtil.getTestFiles().stream().map(test -> dynamicTest(test, () -> compare(test))).toList();
    }
}