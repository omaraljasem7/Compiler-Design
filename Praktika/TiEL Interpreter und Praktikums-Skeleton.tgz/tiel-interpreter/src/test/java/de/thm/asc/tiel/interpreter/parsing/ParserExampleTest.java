package de.thm.asc.tiel.interpreter.parsing;

import de.thm.asc.tiel.interpreter.scanning.TiELScannerHandwritten;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ParserExampleTest {

    /**
     * Tests if the example grammar of a subset of TiEL behaves identically to the full handwritten parser. Must pass for assignment 2.
     * Passing this test but not the other parser tests indicates that the construction of the LL1 table is correct, but there is an issue with the context free grammar.
     */
    @Test
    public void example() {
        var source = "test = 2 + 3; axolotl = test - 2;";

        var handwrittenScannerTokens = TiELScannerHandwritten.getScanner().scan(source);

        var generatedParserStatements = ParserExample.getParser().parse(handwrittenScannerTokens);
        var handwrittenParserStatements = TiELParserHandwritten.getParser().parse(handwrittenScannerTokens);

        assertEquals(generatedParserStatements, handwrittenParserStatements);
    }
}