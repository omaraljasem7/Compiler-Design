package de.thm.asc.tiel.interpreter.backend;

import de.thm.asc.teir.StackInstruction;
import de.thm.asc.tiel.interpreter.ast.stmt.Stmt;
import de.thm.asc.tiel.interpreter.backend.codegeneration.CodeGenerator;
import de.thm.asc.tiel.interpreter.backend.common.Environment;
import de.thm.asc.tiel.interpreter.backend.common.Globals;
import de.thm.asc.tiel.interpreter.backend.common.TiELCallable;
import de.thm.asc.tiel.interpreter.parsing.TiELParserHandwritten;
import de.thm.asc.tiel.interpreter.scanning.TiELScannerHandwritten;
import de.thm.asc.tiel.util.ResourceUtil;
import jdk.jfr.Name;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

class TiELBackendTest {

    List<Stmt> scanAndParse(String test) {
        var source = ResourceUtil.getTestSourceCode(test);

        var tokens = TiELScannerHandwritten.getScanner().scan(source);
        return TiELParserHandwritten.getParser().parse(tokens);
    }

    boolean environmentEquals(Environment e1, Environment e2) {
        if (!e1.variableNames().equals(e2.variableNames())) return false;

        for (var name : e1.variableNames()) {
            var v1 = e1.get(name, null);

            if (v1 instanceof TiELCallable) continue;

            if (!v1.equals(e2.get(name, null))) return false;

        }

        return true;
    }

    private void compare(String test) {
        var statements = scanAndParse(test);

        var interpreterOutputStream = new ByteArrayOutputStream();
        var teirOutputStream = new ByteArrayOutputStream();

        var interpreterEnvironment = Globals.initGlobalEnvironment(new PrintStream(interpreterOutputStream));
        var teirEnvironment = Globals.initGlobalEnvironment(new PrintStream(teirOutputStream));

        TiELBackend.interpreterBackend().build(statements).executeIn(interpreterEnvironment);
        TiELBackend.teirVMBackend().build(statements).executeIn(teirEnvironment);

        assertEquals(interpreterOutputStream.toString(), teirOutputStream.toString());
        assertTrue(environmentEquals(interpreterEnvironment, teirEnvironment));
    }

    /**
     * Tests that the interpreter and code generator backends behave identically. Must pass for assignments 3 and 4 (Bonus).
     */
    @TestFactory
    public List<DynamicTest> testBackendEquivalence() throws IOException {
        return ResourceUtil.getTestFiles().stream().map(test -> dynamicTest(test, () -> compare(test))).toList();
    }

    /**
     * Tests that no interpreter fallback instructions are used for code generation of expressions. Must pass for assignment 3.
     */
    @TestFactory
    public List<DynamicTest> testNoExpressionFallback() throws IOException {
        return ResourceUtil.getTestFiles().stream().map(test -> dynamicTest(test, () -> {
            var code = CodeGenerator.generate(scanAndParse(test));

            code.forEach(c -> assertFalse(c instanceof StackInstruction.TiELInterpretedExpressionFallback));
        })).toList();
    }

    /**
     * Tests that no interpreter fallback instructions are used for code generation of statements. Must pass for assignment 4 (Bonus).
     */
    @TestFactory
    public List<DynamicTest> testNoStatementFallback() throws IOException {
        return ResourceUtil.getTestFiles().stream().map(test -> dynamicTest(test, () -> {
            var code = CodeGenerator.generate(scanAndParse(test));

            code.forEach(c -> assertFalse(c instanceof StackInstruction.TiELInterpretedStatementFallback));
        })).toList();
    }
}