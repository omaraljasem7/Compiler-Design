rootProject.name = "tiel-lang-generated"

